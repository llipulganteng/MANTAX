import React, { useState } from 'react';
import avatarImg from '../assets/images/mantax_avatar_1790885866443.jpg';
import bgImg from '../assets/images/mantax_cyber_bg_1790885878334.jpg';
import { getAccounts, setStoredLogin } from '../utils/storage';
import { Send, MessageSquare, LogIn, Lock, User, KeyRound, AlertCircle, X } from 'lucide-react';

interface LoginViewProps {
  onLoginSuccess: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const [showModal, setShowModal] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSignIn = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');

    const cleanUser = username.trim();
    const cleanPass = password.trim();

    if (!cleanUser || !cleanPass) {
      setErrorMsg('Harap masukkan username dan password');
      return;
    }

    // Check default credentials or created accounts
    const accounts = getAccounts();
    const matched = accounts.find(
      (acc) => acc.username === cleanUser && acc.password === cleanPass
    );

    if (cleanUser === '09' && cleanPass === '03') {
      const defaultOwner = accounts.find((a) => a.username === '09') || {
        name: 'ANSEN ANTONIO',
        username: '09',
        role: 'OWNER' as const,
        expiry: 'PERMANEN' as const,
      };
      setStoredLogin(true, defaultOwner);
      setShowModal(false);
      onLoginSuccess();
    } else if (matched) {
      setStoredLogin(true, matched);
      setShowModal(false);
      onLoginSuccess();
    } else {
      setErrorMsg('Username atau password salah');
    }
  };

  const handlePrefillDefault = () => {
    setUsername('09');
    setPassword('03');
    setErrorMsg('');
  };

  return (
    <div
      className="relative flex flex-col items-center justify-between min-h-[640px] h-full w-full px-5 py-8 select-none overflow-y-auto"
      style={{
        backgroundImage: `linear-gradient(rgba(7, 16, 42, 0.90), rgba(7, 16, 42, 0.95)), url(${bgImg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {/* Top Branding Section */}
      <div className="w-full flex flex-col items-center pt-4">
        {/* Cyber Logo */}
        <div className="relative mb-3">
          <div className="w-[136px] h-[136px] rounded-2xl overflow-hidden shadow-2xl shadow-cyan-500/25 border border-[#00cfff]/40">
            <img
              src={avatarImg}
              alt="MANTAX Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-1 -right-1 bg-[#151a3d] border border-[#00cfff]/50 px-2 py-0.5 rounded text-[10px] text-[#00cfff] font-mono-code font-bold">
            v2.8
          </div>
        </div>

        {/* Title & Subtitle */}
        <h1 className="text-[32px] font-extrabold tracking-wider text-[#00cfff] font-tech text-center drop-shadow-[0_0_10px_rgba(0,207,255,0.4)]">
          MANTAX
        </h1>
        <p className="text-[12px] text-[#a8b0c8] text-center font-medium mt-0.5">
          Advanced Security &amp; Protection System
        </p>

        {/* Sign In Primary Action Button */}
        <div className="w-full max-w-[340px] mt-8">
          <button
            onClick={() => {
              setShowModal(true);
              setErrorMsg('');
            }}
            className="w-full h-[56px] rounded-[18px] bg-[#151a3d] hover:bg-[#1a214d] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/60 text-[#f4f7ff] font-bold text-[14px] flex items-center justify-center gap-2.5 transition-all shadow-lg shadow-black/40 cursor-pointer"
          >
            <LogIn className="w-4 h-4 text-[#00cfff]" />
            <span>↪ &nbsp; SIGN IN</span>
          </button>
        </div>

        {/* Connect With Us */}
        <div className="w-full max-w-[340px] mt-6">
          <p className="text-[11px] font-bold text-[#00cfff] tracking-wider mb-2.5 font-mono-code text-center">
            CONNECT WITH US
          </p>

          <div className="grid grid-cols-2 gap-2.5">
            <a
              href="https://t.me/AZXV71"
              target="_blank"
              rel="noreferrer noopener"
              className="h-[52px] rounded-[18px] bg-[#151a3d] hover:bg-[#1c2454] border border-[#2c345e] hover:border-[#00cfff]/50 text-[#f4f7ff] text-[13px] font-semibold flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
            >
              <Send className="w-3.5 h-3.5 text-[#00cfff]" />
              <span>◉ Telegram</span>
            </a>

            <a
              href="https://wa.me/053897312223"
              target="_blank"
              rel="noreferrer noopener"
              className="h-[52px] rounded-[18px] bg-[#151a3d] hover:bg-[#1c2454] border border-[#2c345e] hover:border-[#00cfff]/50 text-[#f4f7ff] text-[13px] font-semibold flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>◉ WhatsApp</span>
            </a>
          </div>
        </div>
      </div>

      {/* Footer Branding */}
      <div className="w-full text-center pt-8 pb-2 space-y-1">
        <p className="text-[11px] text-[#a8b0c8] font-medium">
          &copy; 2026 MANTAX
        </p>
        <p className="text-[10px] text-[#a8b0c8]/80 font-mono-code">
          ● Secure &nbsp; ● Reliable &nbsp; ● Professional
        </p>
      </div>

      {/* LOGIN MODAL (Replicating Android AlertDialog) */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-[340px] bg-[#151a3d] border border-[#2c345e] rounded-[22px] p-5 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#2c345e]/60">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-[#00cfff] animate-ping" />
                <h3 className="text-[16px] font-bold text-[#f4f7ff] tracking-wide font-tech">
                  MANTAX LOGIN
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-[#a8b0c8] hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick prefill tip */}
            <div className="mt-3 py-1.5 px-2.5 bg-[#0c122d] border border-[#2c345e]/70 rounded-xl flex items-center justify-between">
              <span className="text-[11px] text-[#a8b0c8]">Default PIN:</span>
              <button
                type="button"
                onClick={handlePrefillDefault}
                className="text-[11px] font-mono-code font-bold text-[#00cfff] hover:underline cursor-pointer flex items-center gap-1"
              >
                <KeyRound className="w-3 h-3" />
                User: 09 | Pass: 03
              </button>
            </div>

            {/* Inputs */}
            <form onSubmit={handleSignIn} className="space-y-3 mt-3">
              <div>
                <label className="block text-[11px] font-semibold text-[#a8b0c8] mb-1">
                  Username
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#a8b0c8]" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Username"
                    autoFocus
                    className="w-full h-[46px] pl-9 pr-3 rounded-[14px] bg-[#0c122d] border border-[#2c345e] text-white text-[14px] focus:outline-none focus:border-[#00cfff] placeholder-[#a8b0c8]/60 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#a8b0c8] mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#a8b0c8]" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    className="w-full h-[46px] pl-9 pr-3 rounded-[14px] bg-[#0c122d] border border-[#2c345e] text-white text-[14px] focus:outline-none focus:border-[#00cfff] placeholder-[#a8b0c8]/60 transition-colors"
                  />
                </div>
              </div>

              {errorMsg && (
                <div className="p-2 rounded-lg bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[11px] flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Action Buttons (Positive and Negative from Android AlertDialog) */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 h-[44px] rounded-[14px] bg-[#0c122d] border border-[#2c345e] text-[#a8b0c8] hover:text-white font-medium text-[13px] transition-colors cursor-pointer"
                >
                  BATAL
                </button>
                <button
                  type="submit"
                  className="flex-1 h-[44px] rounded-[14px] bg-[#00cfff] hover:bg-[#33d9ff] active:scale-[0.98] text-[#07102a] font-bold text-[13px] shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
                >
                  SIGN IN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
