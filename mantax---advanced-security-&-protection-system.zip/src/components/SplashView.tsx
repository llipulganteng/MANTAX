import React, { useEffect } from 'react';
import avatarImg from '../assets/images/mantax_avatar_1790885866443.jpg';
import bgImg from '../assets/images/mantax_cyber_bg_1790885878334.jpg';

interface SplashViewProps {
  onFinish: () => void;
}

export const SplashView: React.FC<SplashViewProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 1400);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div
      className="relative flex flex-col items-center justify-center min-h-[640px] h-full w-full px-6 py-12 select-none overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(rgba(7, 16, 42, 0.88), rgba(7, 16, 42, 0.94)), url(${bgImg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="flex-1 flex flex-col items-center justify-center space-y-4">
        {/* Mantax Cyber Avatar */}
        <div className="relative group">
          <div className="w-[140px] h-[140px] rounded-2xl overflow-hidden shadow-2xl shadow-cyan-500/20 border border-[#00cfff]/30 transition-transform duration-300">
            <img
              src={avatarImg}
              alt="MANTAX Emblem"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          {/* Subtle pulse ring */}
          <div className="absolute -inset-1 rounded-2xl border border-[#00cfff]/40 animate-pulse pointer-events-none" />
        </div>

        {/* Title */}
        <div className="text-center mt-2">
          <h1 className="text-[34px] font-extrabold tracking-wider text-[#00cfff] font-tech drop-shadow-[0_0_12px_rgba(0,207,255,0.45)]">
            MANTAX
          </h1>
          <p className="text-[12px] text-[#a8b0c8] tracking-wide mt-1 font-medium">
            Advanced Security &amp; Protection System
          </p>
        </div>

        {/* Loading Spinner */}
        <div className="pt-6 flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-[#151a3d] border-t-[#00cfff] border-r-[#246bff] rounded-full animate-spin shadow-[0_0_10px_rgba(0,207,255,0.3)]" />
          <span className="text-[13px] font-bold text-[#f4f7ff] tracking-widest font-mono-code animate-pulse">
            LOADING...
          </span>
        </div>
      </div>

      {/* Skip button affordance */}
      <button
        onClick={onFinish}
        className="text-[11px] text-[#a8b0c8]/70 hover:text-[#00cfff] transition-colors py-2 px-4 cursor-pointer mt-4"
      >
        Tap to continue &rarr;
      </button>
    </div>
  );
};
