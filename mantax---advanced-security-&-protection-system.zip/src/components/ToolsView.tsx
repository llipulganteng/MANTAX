import React from 'react';
import { PageType } from '../types';
import { Wrench, Package, MapPin, BookOpen, Activity, ArrowRight } from 'lucide-react';

interface ToolsViewProps {
  onNavigate: (page: PageType) => void;
}

export const ToolsView: React.FC<ToolsViewProps> = ({ onNavigate }) => {
  const toolList = [
    {
      id: 'apk_manager',
      name: '📦   APK MANAGER',
      description: 'Manage, inspect, and build Android APK packages on this device.',
      page: 'apk_manager' as PageType,
      icon: Package,
      badge: 'BUILD & PACKAGE',
    },
    {
      id: 'location',
      name: '⌖   LOCATION',
      description: 'Access device coordinates, GPS telemetry, and precision accuracy.',
      page: 'location' as PageType,
      icon: MapPin,
      badge: 'TELEMETRY',
    },
    {
      id: 'rules',
      name: '☷   RULES & INFO',
      description: 'Review official system policies, user terms, and protection guidelines.',
      page: 'rules' as PageType,
      icon: BookOpen,
      badge: 'GUIDELINES',
    },
    {
      id: 'activity_log',
      name: '◷   ACTIVITY LOG',
      description: 'Audit trail of authorization events, security scans, and system tasks.',
      page: 'activity_log' as PageType,
      icon: Activity,
      badge: 'SYSTEM AUDIT',
    },
  ];

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-4">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2">
          <Wrench className="w-6 h-6 text-[#00cfff]" />
          <h2 className="text-[24px] font-extrabold text-[#f4f7ff] font-tech tracking-wide">
            TOOLS
          </h2>
        </div>
        <p className="text-[11px] text-[#a8b0c8] mt-0.5">
          Advanced diagnostic utilities, package managers, and telemetry modules.
        </p>
      </div>

      {/* Tools List */}
      <div className="space-y-2.5">
        {toolList.map((tool) => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.id}
              onClick={() => onNavigate(tool.page)}
              className="w-full min-h-[64px] p-3.5 rounded-[18px] bg-[#151a3d] hover:bg-[#1e2554] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/40 transition-all flex items-center justify-between text-left shadow cursor-pointer group"
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-[14px] bg-[#0c122d] border border-[#2c345e] flex items-center justify-center shrink-0 group-hover:border-[#00cfff]/50 transition-colors">
                  <Icon className="w-5 h-5 text-[#00cfff]" />
                </div>
                <div>
                  <h3 className="text-[14px] font-bold text-white tracking-wide">
                    {tool.name}
                  </h3>
                  <p className="text-[11px] text-[#a8b0c8] mt-0.5 leading-snug line-clamp-1">
                    {tool.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 pl-2">
                <span className="text-[9px] font-mono-code text-[#00cfff] bg-[#0c122d] border border-[#2c345e] px-2 py-0.5 rounded-full hidden sm:inline-block">
                  {tool.badge}
                </span>
                <ArrowRight className="w-4 h-4 text-[#a8b0c8] group-hover:text-[#00cfff] group-hover:translate-x-1 transition-all" />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
