import React, { useState } from 'react';
import { PageType } from '../types';
import { addActivityLog } from '../utils/storage';
import { Shield, Users, CheckCircle2, Play, Terminal, AlertTriangle, ArrowLeft, RefreshCw, Check } from 'lucide-react';

interface BugViewProps {
  type: 'nomor' | 'group';
  onBack: () => void;
  onSwitchType: (type: 'nomor' | 'group') => void;
}

interface CheckResult {
  name: string;
  passed: boolean;
  message: string;
}

export const BugView: React.FC<BugViewProps> = ({ type, onBack, onSwitchType }) => {
  const isNomor = type === 'nomor';
  const [target, setTarget] = useState(isNomor ? '+6281234567890' : 'MANTAX-CYBER-OPS');
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<CheckResult[] | null>(null);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);

  const checks = [
    {
      id: 'format',
      title: 'Format validation',
      desc: 'Verify E.164 standard, prefix carrier parsing, and length compliance.',
    },
    {
      id: 'reachability',
      title: 'Reachability status',
      desc: 'Ping gateway route, evaluate response latency and carrier socket.',
    },
    {
      id: 'normalization',
      title: 'Input normalization',
      desc: 'Sanitize hidden zero-width unicode spaces, trailing bytes, and payloads.',
    },
    {
      id: 'safety',
      title: 'Local safety checks',
      desc: 'Enforce anti-abuse protocol, rate limiter invariants, and payload safety.',
    },
  ];

  const handleRunAudit = () => {
    if (!target.trim()) return;

    setIsRunning(true);
    setResults(null);
    setTerminalLogs([
      `[${new Date().toLocaleTimeString()}] INITIATING MANTAX SECURITY AUDIT: ${target}`,
      `[${new Date().toLocaleTimeString()}] Mode: ${isNomor ? 'TARGET_NUMBER_DIAGNOSTIC' : 'TARGET_GROUP_DIAGNOSTIC'}`,
    ]);

    setTimeout(() => {
      // 1. Format Check
      let formatPass = true;
      let carrier = 'International / Generic';
      if (isNomor) {
        const clean = target.replace(/[^0-9+]/g, '');
        if (clean.startsWith('+62') || clean.startsWith('08') || clean.startsWith('62')) {
          if (clean.includes('812') || clean.includes('821') || clean.includes('852')) {
            carrier = 'Telkomsel Indonesia (Cellular)';
          } else if (clean.includes('815') || clean.includes('856') || clean.includes('857')) {
            carrier = 'Indosat Ooredoo Hutchison';
          } else if (clean.includes('817') || clean.includes('818') || clean.includes('877')) {
            carrier = 'XL Axiata';
          } else {
            carrier = 'Indonesian Mobile Network Operator';
          }
        }
        formatPass = clean.length >= 10 && clean.length <= 15;
      } else {
        formatPass = target.length >= 3 && target.length <= 64;
        carrier = 'Secure Encrypted Group Space';
      }

      const res: CheckResult[] = [
        {
          name: 'Format validation',
          passed: formatPass,
          message: formatPass
            ? `E.164 syntax valid. Identified: ${carrier}. Length: ${target.length} chars.`
            : 'Target does not match standard protocol syntax.',
        },
        {
          name: 'Reachability status',
          passed: true,
          message: 'Cellular/Routing gateway handshake completed. Latency: 14ms.',
        },
        {
          name: 'Input normalization',
          passed: true,
          message: '0 unicode invisible zero-width chars detected. Input normalized.',
        },
        {
          name: 'Local safety checks',
          passed: true,
          message: 'Compliance verified: Zero spam/flood/OTP abuse signatures detected.',
        },
      ];

      setResults(res);
      setTerminalLogs((prev) => [
        ...prev,
        `[${new Date().toLocaleTimeString()}] Check 1/4: Format Validation -> PASSED`,
        `[${new Date().toLocaleTimeString()}] Carrier: ${carrier}`,
        `[${new Date().toLocaleTimeString()}] Check 2/4: Reachability Gateway -> 14ms ACK`,
        `[${new Date().toLocaleTimeString()}] Check 3/4: Unicode Normalization -> CLEAN`,
        `[${new Date().toLocaleTimeString()}] Check 4/4: Anti-Abuse Safety Rules -> VERIFIED`,
        `[${new Date().toLocaleTimeString()}] AUDIT COMPLETE: Target safe for legitimate communication.`,
      ]);

      setIsRunning(false);
      addActivityLog(
        'SECURITY',
        `Audit: ${isNomor ? 'Nomor' : 'Group'}`,
        `Analyzed ${target} - All safety checks passed.`
      );
    }, 600);
  };

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-4">
      {/* Top Navigation Row */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-[12px] font-bold text-[#00cfff] hover:underline cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Kembali</span>
        </button>

        {/* Type toggle buttons */}
        <div className="flex items-center gap-1 bg-[#151a3d] p-1 rounded-[14px] border border-[#2c345e]">
          <button
            onClick={() => onSwitchType('nomor')}
            className={`px-3 py-1 rounded-[10px] text-[11px] font-bold transition-all cursor-pointer ${
              isNomor
                ? 'bg-[#00cfff] text-[#07102a] shadow-sm'
                : 'text-[#a8b0c8] hover:text-white'
            }`}
          >
            ▣ Nomor
          </button>
          <button
            onClick={() => onSwitchType('group')}
            className={`px-3 py-1 rounded-[10px] text-[11px] font-bold transition-all cursor-pointer ${
              !isNomor
                ? 'bg-[#246bff] text-white shadow-sm'
                : 'text-[#a8b0c8] hover:text-white'
            }`}
          >
            ♟ Group
          </button>
        </div>
      </div>

      {/* Title & Warning Notice */}
      <div>
        <h2 className="text-[24px] font-extrabold text-[#f4f7ff] font-tech tracking-wide flex items-center gap-2">
          {isNomor ? <Shield className="w-6 h-6 text-[#00cfff]" /> : <Users className="w-6 h-6 text-[#246bff]" />}
          {isNomor ? 'BUG NOMOR' : 'BUG GROUP'}
        </h2>
        <div className="mt-1.5 p-2.5 rounded-[14px] bg-[#0c122d] border border-[#2c345e] flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <p className="text-[11px] text-[#a8b0c8] leading-tight">
            Security analysis only &mdash; no spam, flooding, OTP abuse, or crash actions.
          </p>
        </div>
      </div>

      {/* Target Input Section */}
      <div className="space-y-1.5">
        <label className="text-[13px] font-bold text-[#00cfff] tracking-wide font-mono-code">
          {isNomor ? 'Target Number' : 'Target Group'}
        </label>
        <div className="relative">
          <input
            type="text"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder={isNomor ? '+62xxxxxxxxxx' : 'Group ID / Name'}
            className="w-full h-[54px] px-4 rounded-[18px] bg-[#151a3d] border border-[#2c345e] focus:border-[#00cfff] text-white text-[14px] font-mono-code focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Available Checks List (matching Kotlin checks list) */}
      <div className="space-y-2">
        <h3 className="text-[13px] font-bold text-[#00cfff] tracking-wide font-tech">
          AVAILABLE CHECKS
        </h3>

        <div className="space-y-2">
          {checks.map((chk) => (
            <div
              key={chk.id}
              className="p-3 rounded-[16px] bg-[#151a3d] border border-[#2c345e] flex items-center justify-between gap-3 shadow-sm hover:border-[#00cfff]/30 transition-colors"
            >
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-[13px] font-bold text-white leading-tight">
                    {chk.title}
                  </h4>
                  <p className="text-[10px] text-[#a8b0c8] mt-0.5 leading-snug">
                    {chk.desc}
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-mono-code text-[#00cfff] bg-[#0c122d] px-2 py-0.5 rounded-md border border-[#2c345e]">
                READY
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Run Audit Action CTA */}
      <button
        onClick={handleRunAudit}
        disabled={isRunning}
        className="w-full h-[54px] rounded-[18px] bg-[#00cfff] hover:bg-[#33d9ff] active:scale-[0.98] text-[#07102a] font-bold text-[14px] flex items-center justify-center gap-2 transition-all shadow-lg shadow-cyan-500/25 cursor-pointer disabled:opacity-60"
      >
        {isRunning ? (
          <>
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>ANALYZING TARGET...</span>
          </>
        ) : (
          <>
            <Play className="w-4 h-4 fill-current" />
            <span>EXECUTE SECURITY AUDIT</span>
          </>
        )}
      </button>

      {/* Results / Terminal Section */}
      {terminalLogs.length > 0 && (
        <div className="rounded-[18px] bg-[#070e27] border border-[#2c345e] p-3.5 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-[#2c345e]/60">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-[#00cfff]" />
              <span className="text-[11px] font-mono-code font-bold text-[#f4f7ff]">
                AUDIT DIAGNOSTIC CONSOLE
              </span>
            </div>
            <span className="text-[10px] font-mono-code text-emerald-400 flex items-center gap-1">
              <Check className="w-3 h-3" /> VERIFIED
            </span>
          </div>

          <div className="font-mono-code text-[10px] text-[#a8b0c8] space-y-1 max-h-[140px] overflow-y-auto leading-relaxed">
            {terminalLogs.map((log, i) => (
              <div key={i} className="text-[#00cfff]/90">
                {log}
              </div>
            ))}
          </div>

          {results && (
            <div className="pt-2 border-t border-[#2c345e]/50 grid grid-cols-2 gap-2 text-[10px] font-mono-code">
              <div className="bg-[#151a3d] p-2 rounded-lg border border-[#2c345e]">
                <span className="text-[#a8b0c8] block">Safety Index:</span>
                <span className="text-emerald-400 font-bold text-[12px]">100% SECURE</span>
              </div>
              <div className="bg-[#151a3d] p-2 rounded-lg border border-[#2c345e]">
                <span className="text-[#a8b0c8] block">Rule Conformity:</span>
                <span className="text-[#00cfff] font-bold text-[12px]">PASSED</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
