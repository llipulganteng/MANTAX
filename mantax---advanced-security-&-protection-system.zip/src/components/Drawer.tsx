import React from 'react';
import { PageType } from '../types';
import { getCurrentUser } from '../utils/storage';
import { Home, Users, History, Package, MapPin, LogOut, X, Shield, BookOpen, Smartphone } from 'lucide-react';

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: PageType) => void;
  onLogout: () => void;
}

export const Drawer: React.FC<DrawerProps> = ({ isOpen, onClose, onNavigate, onLogout }) => {
  if (!isOpen) return null;

  const user = getCurrentUser();

  const menuItems = [
    { label: '⌂  Home', icon: Home, page: 'home' as PageType },
    { label: '♟  Owner Page', icon: Users, page: 'accounts' as PageType },
    { label: '🤖  Android Native Project', icon: Smartphone, page: 'android_export' as PageType },
    { label: '☷  Rules & Info', icon: BookOpen, page: 'rules' as PageType },
    { label: '◷  Riwayat Aktivitas', icon: History, page: 'activity_log' as PageType },
    { label: '📦  APK Manager', icon: Package, page: 'apk_manager' as PageType },
    { label: '⌖  Location', icon: MapPin, page: 'location' as PageType },
  ];

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity animate-in fade-in"
        onClick={onClose}
      />

      {/* Drawer content matching Kotlin PopupWindow */}
      <div className="relative w-[300px] max-w-[85vw] h-full bg-[#070e27] border-r border-[#2c345e] p-5 pt-8 flex flex-col justify-between shadow-2xl z-10 animate-in slide-in-from-left duration-200">
        <div>
          {/* Top Brand */}
          <div className="flex items-center justify-between pb-4 border-b border-[#2c345e]/50">
            <div>
              <div className="flex items-center gap-2">
                <Shield className="w-6 h-6 text-[#00cfff]" />
                <h2 className="text-[26px] font-extrabold text-[#00cfff] font-tech tracking-wider">
                  MANTAX
                </h2>
              </div>
              <p className="text-[13px] font-bold text-white tracking-wide mt-1">
                {user.name}
              </p>
              <p className="text-[11px] text-[#00cfff] font-mono-code">
                {user.role} &bull; @{user.username}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-[#151a3d] text-[#a8b0c8] hover:text-white border border-[#2c345e] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Menu Items */}
          <div className="mt-5 space-y-2">
            {menuItems.map((item, idx) => {
              const Icon = item.icon;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    onNavigate(item.page);
                    onClose();
                  }}
                  className="w-full h-[52px] px-4 rounded-[18px] bg-[#151a3d] hover:bg-[#1e2554] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/40 text-[#f4f7ff] text-[13px] font-semibold flex items-center gap-3 transition-all cursor-pointer shadow-sm text-left"
                >
                  <Icon className="w-4 h-4 text-[#00cfff] shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Log Out */}
        <div className="pt-4 border-t border-[#2c345e]/50">
          <button
            onClick={() => {
              onClose();
              onLogout();
            }}
            className="w-full h-[52px] px-4 rounded-[18px] bg-[#151a3d] hover:bg-rose-950/40 border border-[#2c345e] hover:border-rose-500/50 text-rose-300 text-[13px] font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>↪  Log Out</span>
          </button>
          <p className="text-[10px] text-center text-[#a8b0c8]/60 mt-3 font-mono-code">
            MANTAX Security Core v2.8
          </p>
        </div>
      </div>
    </div>
  );
};
