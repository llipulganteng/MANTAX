import React, { useState } from 'react';
import { ActivityLog } from '../types';
import { getActivityLogs } from '../utils/storage';
import { History, ArrowLeft, Shield, Key, Package, MapPin, Activity } from 'lucide-react';

interface ActivityLogViewProps {
  onBack: () => void;
}

export const ActivityLogView: React.FC<ActivityLogViewProps> = ({ onBack }) => {
  const [logs] = useState<ActivityLog[]>(getActivityLogs());

  const getCategoryIcon = (cat: ActivityLog['category']) => {
    switch (cat) {
      case 'AUTH':
        return <Key className="w-4 h-4 text-[#00cfff]" />;
      case 'SECURITY':
        return <Shield className="w-4 h-4 text-emerald-400" />;
      case 'ACCOUNT':
        return <Activity className="w-4 h-4 text-purple-400" />;
      case 'APK':
        return <Package className="w-4 h-4 text-[#246bff]" />;
      case 'GEO':
        return <MapPin className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-4">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-[12px] font-bold text-[#00cfff] hover:underline cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Kembali</span>
      </button>

      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <History className="w-6 h-6 text-[#00cfff]" />
          <h2 className="text-[24px] font-extrabold text-[#f4f7ff] font-tech tracking-wide">
            RIWAYAT AKTIVITAS
          </h2>
        </div>
        <p className="text-[11px] text-[#a8b0c8] mt-0.5">
          Real-time security log and authorization audit trail.
        </p>
      </div>

      {/* Log items */}
      <div className="space-y-2">
        {logs.map((log) => (
          <div
            key={log.id}
            className="p-3 rounded-[16px] bg-[#151a3d] border border-[#2c345e] flex items-start gap-3 shadow-sm hover:border-[#00cfff]/30 transition-colors"
          >
            <div className="p-2 rounded-[10px] bg-[#0c122d] border border-[#2c345e] shrink-0 mt-0.5">
              {getCategoryIcon(log.category)}
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between">
                <h4 className="text-[13px] font-bold text-white tracking-wide">
                  {log.action}
                </h4>
                <span className="text-[10px] font-mono-code text-[#a8b0c8] shrink-0">
                  {log.timestamp.slice(11, 19)}
                </span>
              </div>
              <p className="text-[11px] text-[#a8b0c8] mt-0.5 leading-snug">
                {log.details}
              </p>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-[9px] font-mono-code text-[#00cfff] bg-[#0c122d] px-1.5 py-0.5 rounded border border-[#2c345e]">
                  {log.category}
                </span>
                <span className="text-[9px] text-[#a8b0c8]/60 font-mono-code">
                  {log.timestamp.slice(0, 10)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
