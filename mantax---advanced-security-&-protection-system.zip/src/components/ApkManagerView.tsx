import React, { useState, useRef } from 'react';
import { ApkPackage } from '../types';
import { getApks, addApk, clearApks } from '../utils/storage';
import { Package, Plus, Hammer, Trash2, ArrowLeft, Check, Download, FileCode2, X, Info } from 'lucide-react';

interface ApkManagerViewProps {
  onBack: () => void;
  onNavigateToAndroidExport?: () => void;
}

export const ApkManagerView: React.FC<ApkManagerViewProps> = ({ onBack, onNavigateToAndroidExport }) => {
  const [apks, setApks] = useState<ApkPackage[]>(getApks());
  const [selectedApk, setSelectedApk] = useState<ApkPackage | null>(null);
  const [showBuildModal, setShowBuildModal] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const sizeMb = (file.size / (1024 * 1024)).toFixed(1) + ' MB';
    const cleanName = file.name;
    const versionMatch = cleanName.match(/v?(\d+\.\d+(\.\d+)?)/i);
    const ver = versionMatch ? versionMatch[0] : '1.0.0-release';

    const newItem = addApk({
      name: cleanName,
      version: ver,
      size: sizeMb,
      packageName: 'com.mantax.app',
      sha256: Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
    });

    setApks(getApks());
    showToast(`APK ${cleanName} berhasil ditambahkan.`);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleClearList = () => {
    clearApks();
    setApks([]);
    showToast('Daftar APK telah dibersihkan.');
  };

  const handleBuildApk = () => {
    setShowBuildModal(true);
  };

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-4">
      {/* Hidden file input for uploading APK */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".apk,.zip,application/vnd.android.package-archive"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Toast */}
      {toastMsg && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-[#151a3d] border border-[#00cfff] text-[#00cfff] text-[12px] font-mono-code shadow-2xl animate-in fade-in">
          {toastMsg}
        </div>
      )}

      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-[12px] font-bold text-[#00cfff] hover:underline cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Kembali ke Tools</span>
      </button>

      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Package className="w-6 h-6 text-[#00cfff]" />
          <h2 className="text-[24px] font-extrabold text-[#f4f7ff] font-tech tracking-wide">
            APK MANAGER
          </h2>
        </div>
        <p className="text-[11px] text-[#a8b0c8] mt-0.5">
          Manage APK files on this device.
        </p>
      </div>

      {/* Main Action Buttons */}
      <div className="space-y-2">
        {/* ANDROID NATIVE & COMPOSE EXPORT */}
        {onNavigateToAndroidExport && (
          <>
            <button
              onClick={onNavigateToAndroidExport}
              className="w-full h-[56px] rounded-[18px] bg-gradient-to-r from-[#151a3d] to-[#1e2554] border border-[#00cfff]/70 hover:border-[#00cfff] text-white font-bold text-[13px] flex items-center justify-between px-4 transition-all shadow-lg shadow-cyan-500/20 cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Package className="w-5 h-5 text-[#00cfff]" />
                <div className="text-left">
                  <span className="block text-[13px] text-white font-tech">PROJECT ANDROID NATIVE</span>
                  <span className="block text-[10px] text-[#00cfff] font-mono-code">Kotlin &amp; Jetpack Compose (.ZIP)</span>
                </div>
              </div>
              <span className="text-[11px] font-mono-code bg-[#00cfff] text-[#07102a] px-2.5 py-1 rounded-md font-bold">
                Buka &rarr;
              </span>
            </button>

            <button
              onClick={onNavigateToAndroidExport}
              className="w-full h-[52px] rounded-[18px] bg-[#0c122d] hover:bg-[#151a3d] border border-emerald-500/50 hover:border-emerald-400 text-white font-bold text-[13px] flex items-center justify-between px-4 transition-all shadow cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-emerald-400 font-bold">🔌</span>
                <span className="text-[12px] text-white font-tech">INSTALL KE HP VIA WEBADB (USB)</span>
              </div>
              <span className="text-[10px] font-mono-code text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded bg-emerald-950/40">
                BROWSER ADB
              </span>
            </button>
          </>
        )}

        {/* ADD APK */}
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full h-[54px] rounded-[18px] bg-[#151a3d] hover:bg-[#1e2554] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/60 text-white font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
        >
          <Plus className="w-4 h-4 text-[#00cfff]" />
          <span>＋ &nbsp; ADD APK</span>
        </button>

        {/* BUILD APK */}
        <button
          onClick={handleBuildApk}
          className="w-full h-[54px] rounded-[18px] bg-[#151a3d] hover:bg-[#1e2554] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/60 text-white font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
        >
          <Hammer className="w-4 h-4 text-[#246bff]" />
          <span>⚙ &nbsp; BUILD APK</span>
        </button>

        {/* CLEAR LIST */}
        <button
          onClick={handleClearList}
          className="w-full h-[54px] rounded-[18px] bg-[#151a3d] hover:bg-rose-950/30 active:scale-[0.98] border border-[#2c345e] hover:border-rose-500/50 text-rose-300 font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
        >
          <Trash2 className="w-4 h-4 text-rose-400" />
          <span>🗑 &nbsp; CLEAR LIST</span>
        </button>
      </div>

      {/* Stored APK list */}
      <div className="space-y-2 pt-2">
        <h3 className="text-[13px] font-bold text-[#00cfff] tracking-wide font-tech">
          INSTALLED / STORED PACKAGES
        </h3>

        {apks.length > 0 ? (
          <div className="space-y-2">
            {apks.map((apk) => (
              <div
                key={apk.id}
                onClick={() => setSelectedApk(apk)}
                className="p-3 rounded-[18px] bg-[#151a3d] border border-[#2c345e] hover:border-[#00cfff]/50 flex items-center justify-between cursor-pointer transition-all shadow-sm"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-[12px] bg-[#0c122d] border border-[#00cfff]/30 flex items-center justify-center shrink-0">
                    <FileCode2 className="w-5 h-5 text-[#00cfff]" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-[13px] font-bold text-white font-mono-code truncate">
                      {apk.name}
                    </h4>
                    <p className="text-[10px] text-[#a8b0c8] font-mono-code mt-0.5">
                      {apk.size} &bull; {apk.version} &bull; Tap to open
                    </p>
                  </div>
                </div>

                <span className="text-[10px] text-[#00cfff] font-mono-code bg-[#0c122d] px-2 py-1 rounded-md border border-[#2c345e] shrink-0">
                  Inspect
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-6 rounded-[18px] bg-[#0c122d] border border-[#2c345e]/70 text-center space-y-2">
            <Info className="w-6 h-6 text-[#a8b0c8] mx-auto opacity-70" />
            <p className="text-[12px] text-[#a8b0c8]">
              Belum ada APK yang ditambahkan.
            </p>
            <p className="text-[10px] text-[#a8b0c8]/60">
              Gunakan tombol &quot;＋ ADD APK&quot; di atas untuk memilih file archive perangkat.
            </p>
          </div>
        )}
      </div>

      {/* APK INSPECTOR MODAL */}
      {selectedApk && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="w-full max-w-[340px] bg-[#151a3d] border border-[#2c345e] rounded-[22px] p-5 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-[#2c345e]">
              <h3 className="text-[15px] font-bold text-[#f4f7ff] font-tech truncate">
                {selectedApk.name}
              </h3>
              <button
                onClick={() => setSelectedApk(null)}
                className="text-[#a8b0c8] hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 py-4 text-[11px] font-mono-code">
              <div>
                <span className="text-[#a8b0c8] block">Package:</span>
                <span className="text-white font-bold">{selectedApk.packageName}</span>
              </div>
              <div>
                <span className="text-[#a8b0c8] block">Version:</span>
                <span className="text-[#00cfff] font-bold">{selectedApk.version}</span>
              </div>
              <div>
                <span className="text-[#a8b0c8] block">Size:</span>
                <span className="text-white">{selectedApk.size}</span>
              </div>
              <div>
                <span className="text-[#a8b0c8] block">SHA-256 Checksum:</span>
                <span className="text-[#a8b0c8] text-[9px] break-all leading-tight">
                  {selectedApk.sha256}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                showToast(`APK ${selectedApk.name} dipilih dari penyimpanan perangkat.`);
                setSelectedApk(null);
              }}
              className="w-full h-[42px] rounded-[14px] bg-[#00cfff] text-[#07102a] font-bold text-[12px] shadow-lg shadow-cyan-500/20 cursor-pointer"
            >
              KONFIRMASI PILIHAN
            </button>
          </div>
        </div>
      )}

      {/* BUILD APK MODAL */}
      {showBuildModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="w-full max-w-[360px] bg-[#151a3d] border border-[#2c345e] rounded-[22px] p-5 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-[#2c345e]">
              <div className="flex items-center gap-2">
                <Hammer className="w-4 h-4 text-[#00cfff]" />
                <h3 className="text-[16px] font-bold text-white font-tech">
                  GRADLE BUILD GUIDE
                </h3>
              </div>
              <button
                onClick={() => setShowBuildModal(false)}
                className="text-[#a8b0c8] hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-3 text-[11px] text-[#a8b0c8] space-y-2.5 leading-relaxed font-mono-code">
              <p className="text-white font-semibold">
                Build APK dilakukan melalui Android Studio / Gradle CLI:
              </p>
              <div className="bg-[#0c122d] p-2.5 rounded-[12px] border border-[#2c345e] text-[#00cfff] text-[10px]">
                <code>./gradlew assembleRelease</code>
              </div>
              <p>
                Konfigurasi aplikasi target:
                <br />&bull; Package: <code>com.mantax.app</code>
                <br />&bull; Min SDK: 23 (Android 6.0 Marshmallow)
                <br />&bull; Target SDK: 34 (Android 14)
              </p>
            </div>

            <button
              onClick={() => setShowBuildModal(false)}
              className="w-full h-[40px] rounded-[12px] bg-[#0c122d] border border-[#2c345e] text-[#00cfff] font-bold text-[12px] cursor-pointer"
            >
              MENGERTI
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
