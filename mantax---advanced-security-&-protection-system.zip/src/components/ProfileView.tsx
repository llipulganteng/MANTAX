import React, { useState, useRef } from 'react';
import avatarImg from '../assets/images/mantax_avatar_1790885866443.jpg';
import { getCurrentUser, getProfilePhoto, setProfilePhoto, setStoredLogin } from '../utils/storage';
import { Camera, LogOut, ArrowLeft, Shield, User, Check, Sparkles } from 'lucide-react';

interface ProfileViewProps {
  onBack: () => void;
  onLogout: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onBack, onLogout }) => {
  const user = getCurrentUser();
  const [currentPhoto, setCurrentPhoto] = useState<string>(getProfilePhoto() || avatarImg);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 2500);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setCurrentPhoto(result);
      setProfilePhoto(result);
      showToast('Foto profil berhasil diperbarui.');
    };
    reader.readAsDataURL(file);
  };

  const handleResetToDefault = () => {
    setCurrentPhoto(avatarImg);
    setProfilePhoto(avatarImg);
    showToast('Foto profil kembali ke default Mantax Emblem.');
  };

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-4 select-none overflow-y-auto pb-6">
      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoUpload}
        className="hidden"
      />

      {/* Toast */}
      {toastMsg && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-[#151a3d] border border-[#00cfff] text-[#00cfff] text-[12px] font-mono-code shadow-2xl animate-in fade-in">
          {toastMsg}
        </div>
      )}

      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-[12px] font-bold text-[#00cfff] hover:underline cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Kembali ke Home</span>
      </button>

      {/* Profile Section matching Kotlin showProfile() */}
      <div className="flex flex-col items-center pt-2">
        {/* Avatar Display */}
        <div className="relative group">
          <div className="w-[140px] h-[140px] rounded-[24px] overflow-hidden border-2 border-[#00cfff] shadow-2xl shadow-cyan-500/25 bg-[#0c122d]">
            <img
              src={currentPhoto}
              alt="Profile Avatar"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="absolute bottom-1 right-1 p-2 rounded-full bg-[#151a3d] text-[#00cfff] border border-[#2c345e] shadow hover:scale-110 transition-transform cursor-pointer"
            title="Upload Photo"
          >
            <Camera className="w-4 h-4" />
          </button>
        </div>

        {/* Name & Role */}
        <h3 className="text-[22px] font-extrabold text-white font-tech tracking-wide mt-3 text-center">
          {user.name}
        </h3>
        <p className="text-[12px] text-[#00cfff] font-mono-code font-bold tracking-wider">
          @{user.username} &bull; {user.role} &bull; {user.expiry || 'PERMANEN'}
        </p>

        {/* Security Trust Badge */}
        <div className="mt-2.5 flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0c122d] border border-[#2c345e] text-[10px] text-[#a8b0c8] font-mono-code">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>Sesi Aktif &bull; Akun Terverifikasi</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2 pt-2 max-w-[340px] mx-auto">
        {/* Change Profile Photo Button */}
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full h-[54px] rounded-[18px] bg-[#151a3d] hover:bg-[#1e2554] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/60 text-white font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
        >
          <Camera className="w-4 h-4 text-[#00cfff]" />
          <span>🖼 &nbsp; CHANGE PROFILE PHOTO</span>
        </button>

        {/* Reset photo preset */}
        <button
          onClick={handleResetToDefault}
          className="w-full h-[44px] rounded-[16px] bg-[#0c122d] hover:bg-[#151a3d] border border-[#2c345e] text-[#a8b0c8] hover:text-[#00cfff] text-[12px] font-mono-code flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Reset to Mantax Emblem</span>
        </button>

        {/* Log Out Button */}
        <button
          onClick={onLogout}
          className="w-full h-[54px] rounded-[18px] bg-[#151a3d] hover:bg-rose-950/40 active:scale-[0.98] border border-[#2c345e] hover:border-rose-500/50 text-rose-300 font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
        >
          <LogOut className="w-4 h-4 text-rose-400" />
          <span>↪ &nbsp; LOG OUT</span>
        </button>
      </div>
    </div>
  );
};
