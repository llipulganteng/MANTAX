import React from 'react';
import { ShieldAlert, ArrowLeft, AlertCircle, CheckCircle, Scale } from 'lucide-react';

interface RulesViewProps {
  onBack: () => void;
}

export const RulesView: React.FC<RulesViewProps> = ({ onBack }) => {
  const rules = [
    {
      num: 1,
      title: 'Larangan Barter Akun',
      desc: 'Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apapun.',
      badge: 'STRICT',
    },
    {
      num: 2,
      title: 'Larangan Membagikan Akun',
      desc: 'Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik terdaftar.',
      badge: 'NO SHARE',
    },
    {
      num: 3,
      title: 'Larangan Menjual Akun',
      desc: 'Penjualan akun hanya boleh dilakukan oleh role resmi yang diizinkan (OWNER / DEV).',
      badge: 'AUTHORIZED ONLY',
    },
    {
      num: 4,
      title: 'Larangan Jual Durasi Ilegal',
      desc: 'Dilarang menjual akses di luar ketentuan durasi resmi (1 Hari, 1 Bulan, 1 Tahun, Permanen).',
      badge: 'PRICE INTEGRITY',
    },
    {
      num: 5,
      title: 'Larangan Banting Harga',
      desc: 'Dilarang merusak atau menurunkan harga yang telah ditentukan oleh manajemen MANTAX.',
      badge: 'PRICE FIXING BAN',
    },
  ];

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-4">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-[12px] font-bold text-[#00cfff] hover:underline cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Kembali ke Home</span>
      </button>

      {/* Title */}
      <div>
        <div className="flex items-center gap-2">
          <Scale className="w-6 h-6 text-amber-400" />
          <h2 className="text-[24px] font-extrabold text-[#f4f7ff] font-tech tracking-wide">
            RULES &amp; INFO
          </h2>
        </div>
        <p className="text-[11px] text-[#a8b0c8] mt-0.5">
          Tata tertib resmi keanggotaan dan protokol keamanan ekosistem MANTAX.
        </p>
      </div>

      {/* Rules list */}
      <div className="space-y-2.5">
        {rules.map((rule) => (
          <div
            key={rule.num}
            className="p-3.5 rounded-[18px] bg-[#1e233b] border border-[#2c345e] shadow-md hover:border-[#00cfff]/40 transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-[#151a3d] border border-[#00cfff]/40 text-[#00cfff] text-[12px] font-mono-code font-bold flex items-center justify-center">
                  {rule.num}
                </span>
                <h3 className="text-[14px] font-bold text-white tracking-wide">
                  {rule.title}
                </h3>
              </div>
              <span className="text-[9px] font-mono-code bg-[#0c122d] text-[#00cfff] border border-[#2c345e] px-2 py-0.5 rounded-full">
                {rule.badge}
              </span>
            </div>

            <p className="text-[11px] text-[#a8b0c8] mt-2 leading-relaxed pl-8">
              {rule.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Enforcement & Consequences Notice */}
      <div className="p-3.5 rounded-[18px] bg-[#151a3d] border border-rose-500/30 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-[12px] font-bold text-rose-300">
            Sanksi Pelanggaran
          </h4>
          <p className="text-[11px] text-[#a8b0c8] mt-0.5 leading-snug">
            Setiap pelanggaran aturan di atas akan berakibat pada pemblokiran akun permanen (Blacklist Device &amp; Account) tanpa pengembalian dana.
          </p>
        </div>
      </div>
    </div>
  );
};
