import React, { useState, useRef } from 'react';
import { UserAccount } from '../types';
import {
  getAccounts,
  saveAccount,
  deleteAccount,
  getCurrentUser,
  getAllowedCreationRoles,
  setStoredLogin,
} from '../utils/storage';
import defaultAvatar from '../assets/images/mantax_avatar_1790885866443.jpg';
import {
  Users,
  Plus,
  Trash2,
  Calendar,
  Shield,
  X,
  Check,
  Copy,
  Camera,
  AlertTriangle,
  Lock,
  UserCheck,
  LogIn,
  KeyRound,
} from 'lucide-react';

interface AccountsViewProps {
  onBack: () => void;
}

export const AccountsView: React.FC<AccountsViewProps> = ({ onBack }) => {
  const currentUser = getCurrentUser();
  const [accounts, setAccounts] = useState<UserAccount[]>(getAccounts());
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form Fields
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string>(defaultAvatar);
  const [role, setRole] = useState<UserAccount['role']>('MEMBER');
  const [expiry, setExpiry] = useState<UserAccount['expiry']>('PERMANEN');

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const allowedRoles = getAllowedCreationRoles(currentUser.role);
  const isMember = currentUser.role === 'MEMBER';

  const allRoles: UserAccount['role'][] = ['MEMBER', 'ADMIN', 'OWNER', 'DEV'];
  const expiryOptions: UserAccount['expiry'][] = ['1 HARI', '1 BULAN', '1 TAHUN', 'PERMANEN'];

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2800);
  };

  const handleOpenCreateModal = (presetRole?: UserAccount['role']) => {
    if (isMember) {
      triggerToast('Akses ditolak: MEMBER tidak dapat membuat akun.');
      return;
    }
    const targetRole = presetRole && allowedRoles.includes(presetRole)
      ? presetRole
      : (allowedRoles[0] || 'MEMBER');

    setRole(targetRole);
    setName('');
    setUsername('');
    setPassword('');
    setPhotoUrl(defaultAvatar);
    setExpiry('PERMANEN');
    setIsModalOpen(true);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setPhotoUrl(result);
      triggerToast('Foto profil dipilih.');
    };
    reader.readAsDataURL(file);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();

    if (isMember) {
      triggerToast('Akses ditolak: Akun MEMBER tidak diizinkan membuat akun baru.');
      return;
    }

    const cleanName = name.trim();
    const cleanUser = username.trim();
    const cleanPass = password.trim();

    if (!cleanName) {
      triggerToast('Nama akun harus diisi');
      return;
    }
    if (!cleanUser) {
      triggerToast('Username harus diisi');
      return;
    }
    if (!cleanPass) {
      triggerToast('Password harus diisi');
      return;
    }

    if (!allowedRoles.includes(role)) {
      triggerToast(`Role Anda (${currentUser.role}) tidak berwenang membuat akun dengan role ${role}.`);
      return;
    }

    const created = saveAccount({
      name: cleanName,
      username: cleanUser,
      password: cleanPass,
      photoUrl: photoUrl || defaultAvatar,
      role,
      expiry,
    });

    setAccounts(getAccounts());
    setIsModalOpen(false);
    triggerToast(`Akun "${created.name}" (@${created.username}) berhasil dibuat!`);
  };

  const handleDelete = (id: string, accName: string) => {
    deleteAccount(id);
    setAccounts(getAccounts());
    triggerToast(`Akun "${accName}" telah dihapus.`);
  };

  const handleCopy = (acc: UserAccount) => {
    const text = `MANTAX ACCOUNT:\nNama: ${acc.name}\nUsername: ${acc.username}\nPassword: ${acc.password || ''}\nRole: ${acc.role}\nExpired: ${acc.expiry}`;
    navigator.clipboard?.writeText(text);
    setCopiedId(acc.id);
    triggerToast(`Kredensial ${acc.name} disalin ke clipboard.`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSwitchUser = (acc: UserAccount) => {
    setStoredLogin(true, acc);
    triggerToast(`Beralih ke akun ${acc.name} (${acc.role}).`);
    setTimeout(() => {
      window.location.reload();
    }, 400);
  };

  const getRoleBadgeStyle = (r: UserAccount['role']) => {
    switch (r) {
      case 'DEV':
        return 'text-purple-300 border-purple-500/50 bg-purple-950/40';
      case 'OWNER':
        return 'text-[#00cfff] border-[#00cfff]/50 bg-cyan-950/40';
      case 'ADMIN':
        return 'text-[#246bff] border-[#246bff]/50 bg-blue-950/40';
      case 'MEMBER':
        return 'text-emerald-300 border-emerald-500/50 bg-emerald-950/40';
    }
  };

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-[#151a3d] border border-[#00cfff] text-[#00cfff] text-[12px] font-mono-code shadow-2xl animate-in fade-in slide-in-from-top-2 text-center max-w-[90vw]">
          {toastMessage}
        </div>
      )}

      {/* Header Info */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-6 h-6 text-[#00cfff]" />
            <h2 className="text-[24px] font-extrabold text-[#f4f7ff] font-tech tracking-wide">
              ACCOUNT MANAGEMENT
            </h2>
          </div>
          <p className="text-[11px] text-[#a8b0c8] mt-0.5">
            Kelola dan buat akun pengguna berjenjang sesuai kewenangan role.
          </p>
        </div>
      </div>

      {/* Access Permission Banner */}
      {isMember ? (
        <div className="p-3 rounded-[16px] bg-rose-950/30 border border-rose-500/40 flex items-start gap-2.5">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="text-[11px]">
            <p className="font-bold text-rose-300">
              Akses Dibatasi: Role MEMBER
            </p>
            <p className="text-[#a8b0c8] mt-0.5 leading-snug">
              Role MEMBER tidak boleh membuat akun baru. Akses pembuatan akun hanya dimiliki oleh ADMIN, OWNER, dan DEV.
            </p>
          </div>
        </div>
      ) : (
        <div className="p-3 rounded-[16px] bg-[#0c122d] border border-[#2c345e] flex items-center justify-between">
          <div className="flex items-center gap-2 text-[11px]">
            <UserCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-[#a8b0c8]">Akses Aktif:</span>
            <span className="font-mono-code font-bold text-white">{currentUser.name}</span>
            <span className={`text-[10px] px-2 py-0.2 rounded border font-mono-code ${getRoleBadgeStyle(currentUser.role)}`}>
              {currentUser.role}
            </span>
          </div>

          <button
            onClick={() => handleOpenCreateModal()}
            className="h-[38px] px-3.5 rounded-[12px] bg-[#00cfff] hover:bg-[#33d9ff] active:scale-95 text-[#07102a] font-bold text-[12px] flex items-center gap-1.5 transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>BUAT AKUN</span>
          </button>
        </div>
      )}

      {/* Role Creation Buttons (DEV, OWNER, ADMIN, MEMBER) */}
      {!isMember && (
        <div className="space-y-2">
          <h3 className="text-[12px] font-bold text-[#00cfff] tracking-wide font-tech">
            PILIH ROLE PEMBUATAN AKUN
          </h3>

          <div className="grid grid-cols-2 gap-2">
            {allRoles.map((r) => {
              const isAllowed = allowedRoles.includes(r);
              return (
                <button
                  key={r}
                  onClick={() => isAllowed && handleOpenCreateModal(r)}
                  disabled={!isAllowed}
                  className={`h-[52px] rounded-[16px] border px-3 flex items-center justify-between transition-all shadow text-left ${
                    isAllowed
                      ? 'bg-[#151a3d] hover:bg-[#1e2554] active:scale-[0.98] border-[#2c345e] hover:border-[#00cfff]/50 cursor-pointer'
                      : 'bg-[#0c122d]/60 border-[#2c345e]/40 opacity-40 cursor-not-allowed'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Shield className={`w-4 h-4 ${isAllowed ? 'text-[#00cfff]' : 'text-slate-500'}`} />
                    <div>
                      <span className="text-[13px] font-bold text-white font-tech block leading-none">
                        {r}
                      </span>
                      <span className="text-[9px] text-[#a8b0c8] font-mono-code">
                        {isAllowed ? 'Buat Akun' : 'Terkunci'}
                      </span>
                    </div>
                  </div>
                  {isAllowed ? (
                    <Plus className="w-4 h-4 text-[#00cfff]" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-slate-500" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Expiry options info label */}
      <div className="p-2.5 rounded-[14px] bg-[#0c122d] border border-[#2c345e]/70 flex items-center gap-2 text-[10px] text-[#a8b0c8] font-mono-code">
        <Calendar className="w-3.5 h-3.5 text-[#00cfff] shrink-0" />
        <span>Opsi Durasi: 1 HARI &bull; 1 BULAN &bull; 1 TAHUN &bull; PERMANEN</span>
      </div>

      {/* Stored Accounts / Member List */}
      <div className="space-y-2 pt-1">
        <div className="flex items-center justify-between">
          <h3 className="text-[13px] font-bold text-[#00cfff] tracking-wide font-tech">
            DAFTAR AKUN &amp; MEMBER ({accounts.length})
          </h3>
          <span className="text-[10px] text-[#a8b0c8] font-mono-code">
            Tersimpan
          </span>
        </div>

        <div className="space-y-2.5">
          {accounts.map((acc) => {
            const isOwnerMaster = acc.username === '09' || acc.name === 'ANSEN ANTONIO';
            const isCurrent = currentUser.username === acc.username;

            return (
              <div
                key={acc.id}
                className={`p-3 rounded-[18px] bg-[#151a3d] border transition-all shadow-md flex items-center justify-between gap-3 ${
                  isCurrent ? 'border-[#00cfff]/70 bg-[#151a3d]/90' : 'border-[#2c345e] hover:border-[#2c345e]/80'
                }`}
              >
                {/* 1. PP (Foto Profil) - Ditampilkan Terpisah */}
                <div className="relative w-[50px] h-[50px] rounded-[16px] overflow-hidden border border-[#00cfff]/40 bg-[#0c122d] shrink-0">
                  <img
                    src={acc.photoUrl || defaultAvatar}
                    alt={`PP ${acc.name}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  {isCurrent && (
                    <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 rounded-full border border-[#151a3d]" />
                  )}
                </div>

                {/* 2. Nama, Username, Role, & Expired - Terpisah dari PP */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-[14px] font-bold text-white tracking-wide truncate">
                      {acc.name}
                    </h4>
                    <span
                      className={`text-[9px] font-mono-code font-bold px-2 py-0.5 rounded border ${getRoleBadgeStyle(
                        acc.role
                      )}`}
                    >
                      {acc.role}
                    </span>
                    {isCurrent && (
                      <span className="text-[9px] font-mono-code text-emerald-400 bg-emerald-950/40 border border-emerald-500/40 px-1.5 py-0.2 rounded">
                        Anda
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2.5 text-[11px] font-mono-code text-[#a8b0c8] mt-0.5">
                    <span className="text-[#00cfff]">@{acc.username}</span>
                    <span>&bull;</span>
                    <span className="text-amber-300 font-semibold">Exp: {acc.expiry}</span>
                  </div>

                  <div className="text-[10px] text-[#a8b0c8]/70 font-mono-code mt-0.5">
                    PW: {acc.password ? '••••••' : 'none'} &bull; Dibuat: {acc.createdAt.slice(0, 10)}
                  </div>
                </div>

                {/* 3. Action Buttons */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {/* Switch user */}
                  {!isCurrent && (
                    <button
                      onClick={() => handleSwitchUser(acc)}
                      className="p-2 rounded-[12px] bg-[#0c122d] hover:bg-[#1a214d] text-[#00cfff] border border-[#2c345e] transition-colors cursor-pointer"
                      title="Masuk sebagai akun ini"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Copy credentials */}
                  <button
                    onClick={() => handleCopy(acc)}
                    className="p-2 rounded-[12px] bg-[#0c122d] hover:bg-[#1a214d] text-[#a8b0c8] hover:text-[#00cfff] transition-colors cursor-pointer border border-[#2c345e]"
                    title="Salin Kredensial"
                  >
                    {copiedId === acc.id ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>

                  {/* Delete account */}
                  {!isOwnerMaster && (
                    <button
                      onClick={() => handleDelete(acc.id, acc.name)}
                      className="p-2 rounded-[12px] bg-[#0c122d] hover:bg-rose-950/40 text-[#a8b0c8] hover:text-rose-400 transition-colors cursor-pointer border border-[#2c345e]"
                      title="Hapus Akun"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* FORM PEMBUATAN AKUN MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-[370px] bg-[#151a3d] border border-[#2c345e] rounded-[24px] p-5 shadow-2xl animate-in zoom-in-95 duration-150 my-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#2c345e]">
              <div>
                <h3 className="text-[17px] font-bold text-white font-tech">
                  FORM PEMBUATAN AKUN
                </h3>
                <p className="text-[10px] text-[#a8b0c8] font-mono-code">
                  Oleh: {currentUser.name} ({currentUser.role})
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-[#a8b0c8] hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveAccount} className="space-y-3.5 mt-3.5">
              {/* Foto Profil / PP (Upload & Preview terpisah) */}
              <div>
                <label className="block text-[11px] font-bold text-[#00cfff] mb-1 font-mono-code">
                  FOTO PROFIL / PP
                </label>
                <div className="flex items-center gap-3 p-2.5 rounded-[14px] bg-[#0c122d] border border-[#2c345e]">
                  <div className="relative w-14 h-14 rounded-[14px] overflow-hidden border-2 border-[#00cfff]/60 bg-[#151a3d] shrink-0">
                    <img
                      src={photoUrl}
                      alt="Preview PP"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1">
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="h-[34px] px-3 rounded-[10px] bg-[#151a3d] hover:bg-[#1e2554] border border-[#2c345e] text-white text-[11px] font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Camera className="w-3.5 h-3.5 text-[#00cfff]" />
                      <span>Pilih Foto PP</span>
                    </button>
                    <p className="text-[9px] text-[#a8b0c8] mt-1">
                      PP terpisah dari nama akun
                    </p>
                  </div>
                </div>
              </div>

              {/* 1. Nama */}
              <div>
                <label className="block text-[11px] font-bold text-[#00cfff] mb-1 font-mono-code">
                  NAMA LENGKAP
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Masukkan nama pengguna"
                  required
                  className="w-full h-[44px] px-3.5 rounded-[12px] bg-[#0c122d] border border-[#2c345e] text-white text-[13px] focus:outline-none focus:border-[#00cfff] placeholder-[#a8b0c8]/50 transition-colors"
                />
              </div>

              {/* 2. Username */}
              <div>
                <label className="block text-[11px] font-bold text-[#00cfff] mb-1 font-mono-code">
                  USERNAME
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username untuk login (tanpa spasi)"
                  required
                  className="w-full h-[44px] px-3.5 rounded-[12px] bg-[#0c122d] border border-[#2c345e] text-white text-[13px] font-mono-code focus:outline-none focus:border-[#00cfff] placeholder-[#a8b0c8]/50 transition-colors"
                />
              </div>

              {/* 3. Password */}
              <div>
                <label className="block text-[11px] font-bold text-[#00cfff] mb-1 font-mono-code">
                  PASSWORD
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password akun"
                  required
                  className="w-full h-[44px] px-3.5 rounded-[12px] bg-[#0c122d] border border-[#2c345e] text-white text-[13px] focus:outline-none focus:border-[#00cfff] placeholder-[#a8b0c8]/50 transition-colors"
                />
              </div>

              {/* 4. Role (MEMBER, ADMIN, OWNER, DEV) */}
              <div>
                <label className="block text-[11px] font-bold text-[#00cfff] mb-1 font-mono-code">
                  ROLE AKUN
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {allRoles.map((r) => {
                    const isAvailable = allowedRoles.includes(r);
                    return (
                      <button
                        key={r}
                        type="button"
                        onClick={() => isAvailable && setRole(r)}
                        disabled={!isAvailable}
                        className={`h-[36px] rounded-[10px] text-[11px] font-tech font-bold transition-all ${
                          role === r
                            ? 'bg-[#00cfff] text-[#07102a] shadow-sm'
                            : isAvailable
                            ? 'bg-[#0c122d] border border-[#2c345e] text-[#a8b0c8] hover:text-white cursor-pointer'
                            : 'bg-[#0c122d]/40 border border-[#2c345e]/30 text-slate-600 cursor-not-allowed'
                        }`}
                      >
                        {r}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 5. Expired (1 HARI, 1 BULAN, 1 TAHUN, PERMANEN) */}
              <div>
                <label className="block text-[11px] font-bold text-[#00cfff] mb-1 font-mono-code">
                  MASA EXPIRED
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {expiryOptions.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setExpiry(opt)}
                      className={`h-[34px] rounded-[10px] text-[10px] font-mono-code font-bold transition-all cursor-pointer ${
                        expiry === opt
                          ? 'bg-[#246bff] text-white shadow-sm'
                          : 'bg-[#0c122d] border border-[#2c345e] text-[#a8b0c8] hover:text-white'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Submit / Batal Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 h-[42px] rounded-[12px] bg-[#0c122d] border border-[#2c345e] text-[#a8b0c8] text-[12px] font-bold cursor-pointer hover:text-white transition-colors"
                >
                  BATAL
                </button>
                <button
                  type="submit"
                  className="flex-1 h-[42px] rounded-[12px] bg-[#00cfff] hover:bg-[#33d9ff] text-[#07102a] text-[12px] font-bold shadow-lg shadow-cyan-500/20 cursor-pointer transition-all"
                >
                  SIMPAN AKUN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
