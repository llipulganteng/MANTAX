import React from 'react';
import { PageType } from '../types';
import { Menu, User, Smartphone, Monitor } from 'lucide-react';

interface HeaderProps {
  title: string;
  onOpenDrawer: () => void;
  onOpenProfile: () => void;
  isDeviceFrame: boolean;
  onToggleDeviceFrame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  onOpenDrawer,
  onOpenProfile,
  isDeviceFrame,
  onToggleDeviceFrame,
}) => {
  return (
    <header className="sticky top-0 z-30 w-full h-[62px] px-3.5 flex items-center justify-between bg-[#07102a]/90 backdrop-blur-md border-b border-[#2c345e]/50 select-none">
      {/* Drawer trigger button */}
      <button
        onClick={onOpenDrawer}
        className="w-[44px] h-[44px] rounded-[16px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-95 border border-[#2c345e] text-white flex items-center justify-center text-[18px] transition-all cursor-pointer shadow"
        title="Open Navigation Menu"
        aria-label="Menu"
      >
        <Menu className="w-5 h-5 text-[#00cfff]" />
      </button>

      {/* Title */}
      <div className="flex-1 text-center px-2">
        <h2 className="text-[17px] font-bold text-[#f4f7ff] tracking-wide font-tech truncate">
          {title}
        </h2>
      </div>

      <div className="flex items-center gap-1.5">
        {/* Toggle between mobile frame & full dashboard view */}
        <button
          onClick={onToggleDeviceFrame}
          className="w-[40px] h-[40px] rounded-[14px] bg-[#0c122d] hover:bg-[#151a3d] border border-[#2c345e] text-[#a8b0c8] hover:text-[#00cfff] flex items-center justify-center transition-all cursor-pointer"
          title={isDeviceFrame ? 'Switch to Full Dashboard View' : 'Switch to Mobile App View'}
          aria-label="Toggle Layout"
        >
          {isDeviceFrame ? <Monitor className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
        </button>

        {/* Profile button */}
        <button
          onClick={onOpenProfile}
          className="w-[44px] h-[44px] rounded-[16px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-95 border border-[#2c345e] text-[#00cfff] flex items-center justify-center text-[16px] transition-all cursor-pointer shadow"
          title="Open Profile"
          aria-label="Profile"
        >
          <User className="w-4 h-4 text-[#00cfff]" />
        </button>
      </div>
    </header>
  );
};
