import React from 'react';
import { PageType } from '../types';
import { Home, ShieldAlert, Users, Wrench } from 'lucide-react';

interface BottomNavProps {
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentPage, onNavigate }) => {
  const isBugActive = currentPage === 'bug_nomor' || currentPage === 'bug_group';
  const isAccountsActive = currentPage === 'accounts';
  const isToolsActive = currentPage === 'tools' || currentPage === 'apk_manager' || currentPage === 'location';
  const isHomeActive = currentPage === 'home';

  return (
    <nav className="w-full px-3 py-2 select-none">
      <div className="h-[62px] rounded-[30px] bg-[#131b37] border border-[#2c345e] shadow-xl shadow-black/40 flex items-center justify-around px-2 backdrop-blur-md">
        {/* Home */}
        <button
          onClick={() => onNavigate('home')}
          className={`flex-1 h-[48px] rounded-[22px] flex flex-col items-center justify-center transition-all cursor-pointer ${
            isHomeActive
              ? 'bg-[#151a3d] text-[#00cfff] border border-[#00cfff]/40 shadow-sm'
              : 'text-[#a8b0c8] hover:text-[#f4f7ff]'
          }`}
          title="Home"
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5 font-mono-code">Home</span>
        </button>

        {/* Bug */}
        <button
          onClick={() => onNavigate('bug_nomor')}
          className={`flex-1 h-[48px] rounded-[22px] flex flex-col items-center justify-center transition-all cursor-pointer ${
            isBugActive
              ? 'bg-[#151a3d] text-[#00cfff] border border-[#00cfff]/40 shadow-sm'
              : 'text-[#a8b0c8] hover:text-[#f4f7ff]'
          }`}
          title="Bug Analysis"
        >
          <ShieldAlert className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5 font-mono-code">Bug</span>
        </button>

        {/* Accounts */}
        <button
          onClick={() => onNavigate('accounts')}
          className={`flex-1 h-[48px] rounded-[22px] flex flex-col items-center justify-center transition-all cursor-pointer ${
            isAccountsActive
              ? 'bg-[#151a3d] text-[#00cfff] border border-[#00cfff]/40 shadow-sm'
              : 'text-[#a8b0c8] hover:text-[#f4f7ff]'
          }`}
          title="Accounts"
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5 font-mono-code">Account</span>
        </button>

        {/* Tools */}
        <button
          onClick={() => onNavigate('tools')}
          className={`flex-1 h-[48px] rounded-[22px] flex flex-col items-center justify-center transition-all cursor-pointer ${
            isToolsActive
              ? 'bg-[#151a3d] text-[#00cfff] border border-[#00cfff]/40 shadow-sm'
              : 'text-[#a8b0c8] hover:text-[#f4f7ff]'
          }`}
          title="Tools"
        >
          <Wrench className="w-5 h-5" />
          <span className="text-[10px] font-semibold mt-0.5 font-mono-code">Tools</span>
        </button>
      </div>
    </nav>
  );
};
