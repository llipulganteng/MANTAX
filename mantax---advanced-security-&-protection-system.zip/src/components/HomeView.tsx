import React from 'react';
import { PageType } from '../types';
import avatarImg from '../assets/images/mantax_avatar_1790885866443.jpg';
import { getCurrentUser, getProfilePhoto } from '../utils/storage';
import { Flame, Clover, Zap, Shield, Users, Settings, Send, BookOpen, ExternalLink, ArrowRight } from 'lucide-react';

interface HomeViewProps {
  onNavigate: (page: PageType) => void;
  onOpenRules: () => void;
  onOpenBug: (type: 'nomor' | 'group') => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigate,
  onOpenRules,
  onOpenBug,
}) => {
  const user = getCurrentUser();
  const profilePhoto = getProfilePhoto() || avatarImg;

  return (
    <div className="flex-1 w-full px-4 py-3 space-y-3.5 select-none overflow-y-auto pb-4">
      {/* 1. PROFILE CARD */}
      <div
        onClick={() => onNavigate('profile')}
        className="w-full min-h-[96px] p-3 rounded-[22px] bg-[#151a3d] border border-[#2c345e] hover:border-[#00cfff]/40 transition-all flex items-center gap-3.5 shadow-lg shadow-black/30 cursor-pointer group"
      >
        <div className="relative w-[72px] h-[72px] rounded-[18px] overflow-hidden border border-[#00cfff]/50 shrink-0 bg-[#0c122d]">
          <img
            src={profilePhoto}
            alt="Profile Avatar"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#151a3d]" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="text-[17px] font-bold text-[#f4f7ff] tracking-wide truncate">
              {user.name}
            </h3>
            <span className="text-[10px] font-mono-code bg-[#0c122d] text-[#00cfff] border border-[#00cfff]/30 px-2 py-0.5 rounded-full shrink-0">
              ACTIVE
            </span>
          </div>
          <p className="text-[11px] text-[#00cfff] font-mono-code font-medium">
            @{user.username}
          </p>
          <p className="text-[11px] text-[#a8b0c8] font-mono-code mt-0.5 tracking-tight truncate">
            {user.role} &nbsp;&bull;&nbsp; Exp: {user.expiry || 'PERMANEN'}
          </p>
          <div className="flex items-center gap-2 mt-1 text-[11px] text-[#00cfff] font-medium group-hover:underline">
            <span>Kelola profil &amp; akun</span>
            <ArrowRight className="w-3 h-3" />
          </div>
        </div>
      </div>

      {/* 2. STATISTICS GRID (🔥 Gacor, ☘ 3, ⚡ Fast Send) */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="h-[98px] rounded-[18px] bg-[#0c122d] border border-[#2c345e]/80 p-2.5 flex flex-col items-center justify-center text-center shadow-md">
          <Flame className="w-6 h-6 text-amber-400 mb-1 animate-pulse" />
          <span className="text-[14px] font-bold text-white tracking-wide leading-tight">
            Gacor
          </span>
          <span className="text-[9px] text-[#00cfff] font-mono-code mt-0.5">
            99.9% Uptime
          </span>
        </div>

        <div className="h-[98px] rounded-[18px] bg-[#0c122d] border border-[#2c345e]/80 p-2.5 flex flex-col items-center justify-center text-center shadow-md">
          <Clover className="w-6 h-6 text-emerald-400 mb-1" />
          <span className="text-[18px] font-bold text-white tracking-tight leading-tight font-mono-code">
            3
          </span>
          <span className="text-[9px] text-[#a8b0c8] font-mono-code mt-0.5">
            Shield Nodes
          </span>
        </div>

        <div className="h-[98px] rounded-[18px] bg-[#0c122d] border border-[#2c345e]/80 p-2.5 flex flex-col items-center justify-center text-center shadow-md">
          <Zap className="w-6 h-6 text-[#00cfff] mb-1" />
          <span className="text-[13px] font-bold text-white tracking-wide leading-tight">
            Fast Send
          </span>
          <span className="text-[9px] text-emerald-400 font-mono-code mt-0.5">
            &lt; 15ms Latency
          </span>
        </div>
      </div>

      {/* 3. BUG TABS & TARGET PREVIEW */}
      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => onOpenBug('nomor')}
            className="h-[52px] rounded-[18px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/60 text-white font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
          >
            <Shield className="w-4 h-4 text-[#00cfff]" />
            <span>▣ &nbsp;BUG NOMOR</span>
          </button>

          <button
            onClick={() => onOpenBug('group')}
            className="h-[52px] rounded-[18px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/60 text-white font-bold text-[13px] flex items-center justify-center gap-2 transition-all shadow cursor-pointer"
          >
            <Users className="w-4 h-4 text-[#246bff]" />
            <span>♟ &nbsp;BUG GROUP</span>
          </button>
        </div>

        {/* Target display container matching Kotlin */}
        <div
          onClick={() => onOpenBug('nomor')}
          className="h-[54px] rounded-[16px] bg-[#151a3d] border border-[#2c345e] px-4 flex items-center justify-between text-[#a8b0c8] hover:text-white hover:border-[#00cfff]/40 cursor-pointer transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <span className="text-[12px] font-mono-code text-[#00cfff]">TARGET:</span>
            <span className="text-[14px] font-mono-code text-[#f4f7ff] tracking-wider">
              +62XXXXXXXXXX
            </span>
          </div>
          <span className="text-[11px] text-[#00cfff] font-mono-code">Select &rarr;</span>
        </div>

        {/* Section Label: "▌ PILIH BUG" */}
        <div className="pt-1 flex items-center justify-between">
          <h4 className="text-[13px] font-bold text-[#00cfff] tracking-wide font-tech flex items-center gap-1.5">
            <span className="text-[#00cfff]">▌</span> PILIH BUG
          </h4>
          <span className="text-[10px] text-[#a8b0c8] font-mono-code">
            Analysis &amp; Diagnostics
          </span>
        </div>
      </div>

      {/* 4. QUICK ACTIONS (Manage Bug, Join Channel, Rules & Info) */}
      <div className="grid grid-cols-3 gap-2.5 pt-0.5">
        {/* Manage Bug */}
        <button
          onClick={() => onOpenBug('nomor')}
          className="h-[96px] rounded-[18px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/40 p-2.5 flex flex-col items-center justify-center text-center transition-all shadow cursor-pointer group"
        >
          <Settings className="w-5 h-5 text-[#00cfff] mb-1.5 group-hover:rotate-90 transition-transform duration-300" />
          <span className="text-[12px] font-bold text-white leading-tight">
            Manage Bug
          </span>
          <span className="text-[9px] text-[#a8b0c8] mt-1">Audit Tool</span>
        </button>

        {/* Join Channel */}
        <a
          href="https://t.me/AZXV71"
          target="_blank"
          rel="noreferrer noopener"
          className="h-[96px] rounded-[18px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/40 p-2.5 flex flex-col items-center justify-center text-center transition-all shadow cursor-pointer group"
        >
          <Send className="w-5 h-5 text-[#00cfff] mb-1.5 group-hover:translate-x-0.5 transition-transform" />
          <span className="text-[12px] font-bold text-white leading-tight">
            Join Channel
          </span>
          <span className="text-[9px] text-[#a8b0c8] mt-1 flex items-center gap-0.5">
            Telegram <ExternalLink className="w-2.5 h-2.5" />
          </span>
        </a>

        {/* Rules & Info */}
        <button
          onClick={onOpenRules}
          className="h-[96px] rounded-[18px] bg-[#151a3d] hover:bg-[#1f2656] active:scale-[0.98] border border-[#2c345e] hover:border-[#00cfff]/40 p-2.5 flex flex-col items-center justify-center text-center transition-all shadow cursor-pointer group"
        >
          <BookOpen className="w-5 h-5 text-amber-400 mb-1.5 group-hover:scale-110 transition-transform" />
          <span className="text-[12px] font-bold text-white leading-tight">
            Rules &amp; Info
          </span>
          <span className="text-[9px] text-[#a8b0c8] mt-1">Guidelines</span>
        </button>
      </div>

      {/* System Status Banner */}
      <div className="py-2.5 px-3.5 rounded-[16px] bg-[#0c122d] border border-[#2c345e]/60 flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[#a8b0c8]">Security Engine:</span>
          <span className="font-mono-code font-bold text-[#f4f7ff]">ARMORED</span>
        </div>
        <button
          onClick={() => onNavigate('activity_log')}
          className="text-[#00cfff] font-mono-code hover:underline cursor-pointer"
        >
          View Logs &rarr;
        </button>
      </div>
    </div>
  );
};
