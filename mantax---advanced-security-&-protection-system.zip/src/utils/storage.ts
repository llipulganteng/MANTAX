import { UserAccount, CurrentUserSession, ApkPackage, ActivityLog } from '../types';
import defaultAvatar from '../assets/images/mantax_avatar_1790885866443.jpg';

const STORAGE_KEYS = {
  LOGGED: 'mantax_logged',
  CURRENT_USER_SESSION: 'mantax_current_user_session',
  ACCOUNTS: 'mantax_accounts',
  APKS: 'mantax_apks',
  LOGS: 'mantax_logs',
};

const DEFAULT_ACCOUNTS: UserAccount[] = [
  {
    id: 'acc-01',
    name: 'ANSEN ANTONIO',
    username: '09',
    password: '03',
    role: 'OWNER',
    expiry: 'PERMANEN',
    photoUrl: defaultAvatar,
    createdAt: '2026-01-01 00:00:00',
    status: 'active',
  },
  {
    id: 'acc-02',
    name: 'Admin Mantax Core',
    username: 'admin01',
    password: '777',
    role: 'ADMIN',
    expiry: '1 TAHUN',
    photoUrl: '',
    createdAt: '2026-02-15 12:30:00',
    status: 'active',
  },
  {
    id: 'acc-03',
    name: 'Dev Mantax Engine',
    username: 'dev_ops',
    password: 'dev',
    role: 'DEV',
    expiry: 'PERMANEN',
    photoUrl: '',
    createdAt: '2026-02-20 10:15:00',
    status: 'active',
  },
  {
    id: 'acc-04',
    name: 'User Client Member',
    username: 'member01',
    password: '123',
    role: 'MEMBER',
    expiry: '1 BULAN',
    photoUrl: '',
    createdAt: '2026-03-01 16:40:00',
    status: 'active',
  },
];

const DEFAULT_APKS: ApkPackage[] = [
  {
    id: 'apk-1',
    name: 'Mantax-Security-v2.8.apk',
    version: '2.8.0-release',
    size: '18.4 MB',
    packageName: 'com.mantax.app',
    sha256: '9f83a42c67b2d58e811ac48f9485e921d7b38461abec8f9024c0ef783b2184a2',
    uploadedAt: '2026-03-28 14:20:10',
  },
];

export const getStoredLogin = (): boolean => {
  return localStorage.getItem(STORAGE_KEYS.LOGGED) === 'true';
};

export const setStoredLogin = (
  status: boolean,
  account?: Partial<UserAccount>
) => {
  if (status) {
    const session: CurrentUserSession = {
      id: account?.id || 'acc-01',
      name: account?.name || 'ANSEN ANTONIO',
      username: account?.username || '09',
      role: account?.role || 'OWNER',
      expiry: account?.expiry || 'PERMANEN',
      photoUrl: account?.photoUrl || defaultAvatar,
    };
    localStorage.setItem(STORAGE_KEYS.LOGGED, 'true');
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER_SESSION, JSON.stringify(session));
    addActivityLog('AUTH', 'Sign In', `Pengguna ${session.name} (${session.role}) berhasil masuk.`);
  } else {
    localStorage.removeItem(STORAGE_KEYS.LOGGED);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_SESSION);
    addActivityLog('AUTH', 'Log Out', 'Sesi diakhiri oleh pengguna.');
  }
};

export const getCurrentUser = (): CurrentUserSession => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER_SESSION);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.name) {
        return parsed;
      }
    }
  } catch {}

  return {
    id: 'acc-01',
    name: 'ANSEN ANTONIO',
    username: '09',
    role: 'OWNER',
    expiry: 'PERMANEN',
    photoUrl: defaultAvatar,
  };
};

export const updateCurrentUserProfile = (updates: { name?: string; photoUrl?: string }) => {
  const current = getCurrentUser();
  const updated: CurrentUserSession = {
    ...current,
    name: updates.name ?? current.name,
    photoUrl: updates.photoUrl ?? current.photoUrl,
  };
  localStorage.setItem(STORAGE_KEYS.CURRENT_USER_SESSION, JSON.stringify(updated));

  const accounts = getAccounts();
  const accIndex = accounts.findIndex(a => a.username === current.username);
  if (accIndex >= 0) {
    if (updates.name) accounts[accIndex].name = updates.name;
    if (updates.photoUrl) accounts[accIndex].photoUrl = updates.photoUrl;
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  }

  addActivityLog('ACCOUNT', 'Profil Diperbarui', `Foto / nama profil ${updated.name} diperbarui.`);
  return updated;
};

export const getProfilePhoto = (): string | null => {
  const user = getCurrentUser();
  return user.photoUrl || null;
};

export const setProfilePhoto = (photoDataUrl: string) => {
  updateCurrentUserProfile({ photoUrl: photoDataUrl });
};


export const getAccounts = (): UserAccount[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(DEFAULT_ACCOUNTS));
      return DEFAULT_ACCOUNTS;
    }
    const parsed = JSON.parse(raw);
    // Ensure all accounts have a name and photoUrl
    return parsed.map((acc: any) => ({
      ...acc,
      name: acc.name || (acc.username === '09' ? 'ANSEN ANTONIO' : acc.username),
      photoUrl: acc.photoUrl || (acc.username === '09' ? defaultAvatar : ''),
    }));
  } catch {
    return DEFAULT_ACCOUNTS;
  }
};

export const saveAccount = (
  accountData: Omit<UserAccount, 'id' | 'createdAt' | 'status'>
): UserAccount => {
  const accounts = getAccounts();
  const newAccount: UserAccount = {
    ...accountData,
    id: `acc-${Date.now()}`,
    createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
    status: 'active',
  };
  // Prepend new account or replace if same username
  const updated = [newAccount, ...accounts.filter(a => a.username !== accountData.username)];
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updated));
  addActivityLog(
    'ACCOUNT',
    'Buat Akun Baru',
    `Membuat akun ${accountData.role}: ${accountData.name} (@${accountData.username}, Exp: ${accountData.expiry})`
  );
  return newAccount;
};

export const deleteAccount = (id: string) => {
  const accounts = getAccounts();
  const target = accounts.find(a => a.id === id);
  const updated = accounts.filter(a => a.id !== id);
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updated));
  if (target) {
    addActivityLog('ACCOUNT', 'Hapus Akun', `Menghapus akun "${target.name}" (@${target.username})`);
  }
};

export const getAllowedCreationRoles = (currentUserRole: UserAccount['role']): UserAccount['role'][] => {
  switch (currentUserRole) {
    case 'DEV':
      return ['MEMBER', 'ADMIN', 'OWNER', 'DEV'];
    case 'OWNER':
      return ['MEMBER', 'ADMIN', 'OWNER'];
    case 'ADMIN':
      return ['MEMBER'];
    case 'MEMBER':
    default:
      return []; // MEMBER cannot create accounts
  }
};

export const getApks = (): ApkPackage[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.APKS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.APKS, JSON.stringify(DEFAULT_APKS));
      return DEFAULT_APKS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_APKS;
  }
};

export const addApk = (apk: Omit<ApkPackage, 'id' | 'uploadedAt'>): ApkPackage => {
  const list = getApks();
  const newItem: ApkPackage = {
    ...apk,
    id: `apk-${Date.now()}`,
    uploadedAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
  };
  const updated = [newItem, ...list];
  localStorage.setItem(STORAGE_KEYS.APKS, JSON.stringify(updated));
  addActivityLog('APK', 'Paket Ditambahkan', `Menambahkan paket ${apk.name} (${apk.size})`);
  return newItem;
};

export const clearApks = () => {
  localStorage.setItem(STORAGE_KEYS.APKS, JSON.stringify([]));
  addActivityLog('APK', 'Daftar Paket Dikosongkan', 'Semua file APK dihapus dari penyimpanan.');
};

export const getActivityLogs = (): ActivityLog[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LOGS);
    if (!raw) {
      const initialLogs: ActivityLog[] = [
        {
          id: 'log-1',
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          category: 'SECURITY',
          action: 'Inisialisasi Sistem',
          details: 'MANTAX Core Security Environment berjalan.',
        },
      ];
      localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(initialLogs));
      return initialLogs;
    }
    return JSON.parse(raw);
  } catch {
    return [];
  }
};

export const addActivityLog = (
  category: ActivityLog['category'],
  action: string,
  details: string
) => {
  const logs = getActivityLogs();
  const newLog: ActivityLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
    category,
    action,
    details,
  };
  const updated = [newLog, ...logs.slice(0, 49)];
  localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(updated));
};
