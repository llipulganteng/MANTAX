export type PageType =
  | 'splash'
  | 'login'
  | 'home'
  | 'bug_nomor'
  | 'bug_group'
  | 'rules'
  | 'accounts'
  | 'tools'
  | 'apk_manager'
  | 'location'
  | 'profile'
  | 'activity_log'
  | 'android_export';

export interface UserAccount {
  id: string;
  name: string;        // Nama
  username: string;    // Username
  password?: string;   // Password
  photoUrl?: string;   // Foto profil/PP
  role: 'DEV' | 'OWNER' | 'ADMIN' | 'MEMBER';
  expiry: '1 HARI' | '1 BULAN' | '1 TAHUN' | 'PERMANEN';
  createdAt: string;
  status: 'active' | 'expired';
}

export interface CurrentUserSession {
  id: string;
  name: string;
  username: string;
  role: UserAccount['role'];
  expiry: string;
  photoUrl: string;
}

export interface ApkPackage {
  id: string;
  name: string;
  version: string;
  size: string;
  packageName: string;
  sha256: string;
  uploadedAt: string;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  category: 'AUTH' | 'SECURITY' | 'ACCOUNT' | 'APK' | 'GEO';
  action: string;
  details: string;
}

export interface SecurityCheckItem {
  id: string;
  title: string;
  description: string;
  status: 'idle' | 'running' | 'passed' | 'warning' | 'failed';
  result?: string;
}
