import React, { useState } from 'react';
import { PageType } from './types';
import { getStoredLogin, setStoredLogin } from './utils/storage';
import { SplashView } from './components/SplashView';
import { LoginView } from './components/LoginView';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Drawer } from './components/Drawer';
import { HomeView } from './components/HomeView';
import { BugView } from './components/BugView';
import { RulesView } from './components/RulesView';
import { AccountsView } from './components/AccountsView';
import { ToolsView } from './components/ToolsView';
import { ApkManagerView } from './components/ApkManagerView';
import { LocationView } from './components/LocationView';
import { ProfileView } from './components/ProfileView';
import { ActivityLogView } from './components/ActivityLogView';
import { AndroidExportView } from './components/AndroidExportView';
import bgImg from './assets/images/mantax_cyber_bg_1790885878334.jpg';
import { Wifi, BatteryMedium, Signal, Smartphone } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('splash');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isDeviceFrame, setIsDeviceFrame] = useState(false);

  const getPageTitle = (page: PageType): string => {
    switch (page) {
      case 'home':
        return 'MANTAX';
      case 'bug_nomor':
        return 'BUG NOMOR';
      case 'bug_group':
        return 'BUG GROUP';
      case 'rules':
        return 'RULES & INFO';
      case 'accounts':
        return 'ACCOUNTS';
      case 'tools':
        return 'TOOLS';
      case 'apk_manager':
        return 'APK MANAGER';
      case 'location':
        return 'LOCATION';
      case 'profile':
        return 'PROFILE';
      case 'activity_log':
        return 'RIWAYAT AKTIVITAS';
      case 'android_export':
        return 'ANDROID NATIVE';
      default:
        return 'MANTAX';
    }
  };

  const handleSplashFinish = () => {
    if (getStoredLogin()) {
      setCurrentPage('home');
    } else {
      setCurrentPage('login');
    }
  };

  const handleLogout = () => {
    setStoredLogin(false);
    setCurrentPage('login');
  };

  const showHeader = currentPage !== 'splash' && currentPage !== 'login';
  const showBottomNav =
    currentPage === 'home' ||
    currentPage === 'bug_nomor' ||
    currentPage === 'bug_group' ||
    currentPage === 'accounts' ||
    currentPage === 'tools' ||
    currentPage === 'rules' ||
    currentPage === 'apk_manager' ||
    currentPage === 'location';

  // Render the active view
  const renderCurrentView = () => {
    switch (currentPage) {
      case 'splash':
        return <SplashView onFinish={handleSplashFinish} />;
      case 'login':
        return <LoginView onLoginSuccess={() => setCurrentPage('home')} />;
      case 'home':
        return (
          <HomeView
            onNavigate={(p) => setCurrentPage(p)}
            onOpenRules={() => setCurrentPage('rules')}
            onOpenBug={(type) => setCurrentPage(type === 'nomor' ? 'bug_nomor' : 'bug_group')}
          />
        );
      case 'bug_nomor':
        return (
          <BugView
            type="nomor"
            onBack={() => setCurrentPage('home')}
            onSwitchType={(t) => setCurrentPage(t === 'nomor' ? 'bug_nomor' : 'bug_group')}
          />
        );
      case 'bug_group':
        return (
          <BugView
            type="group"
            onBack={() => setCurrentPage('home')}
            onSwitchType={(t) => setCurrentPage(t === 'nomor' ? 'bug_nomor' : 'bug_group')}
          />
        );
      case 'rules':
        return <RulesView onBack={() => setCurrentPage('home')} />;
      case 'accounts':
        return <AccountsView onBack={() => setCurrentPage('home')} />;
      case 'tools':
        return <ToolsView onNavigate={(p) => setCurrentPage(p)} />;
      case 'apk_manager':
        return (
          <ApkManagerView
            onBack={() => setCurrentPage('tools')}
            onNavigateToAndroidExport={() => setCurrentPage('android_export')}
          />
        );
      case 'location':
        return <LocationView onBack={() => setCurrentPage('tools')} />;
      case 'profile':
        return (
          <ProfileView
            onBack={() => setCurrentPage('home')}
            onLogout={handleLogout}
          />
        );
      case 'activity_log':
        return <ActivityLogView onBack={() => setCurrentPage('home')} />;
      case 'android_export':
        return <AndroidExportView onBack={() => setCurrentPage('apk_manager')} />;
      default:
        return <HomeView onNavigate={(p) => setCurrentPage(p)} onOpenRules={() => setCurrentPage('rules')} onOpenBug={() => setCurrentPage('bug_nomor')} />;
    }
  };

  return (
    <div
      className="min-h-screen w-full bg-[#07102a] text-[#f4f7ff] flex flex-col items-center justify-center relative selection:bg-[#00cfff] selection:text-[#07102a]"
      style={{
        backgroundImage: `radial-gradient(ellipse at 50% 20%, rgba(36, 107, 255, 0.12), transparent 70%), linear-gradient(to bottom, #07102a, #050b1f)`,
      }}
    >
      {/* Side Navigation Drawer */}
      <Drawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={(p) => setCurrentPage(p)}
        onLogout={handleLogout}
      />

      {/* Main Container */}
      <div
        className={`w-full transition-all duration-300 flex flex-col ${
          isDeviceFrame
            ? 'max-w-[420px] h-[860px] max-h-[95vh] rounded-[42px] border-4 border-[#2c345e] shadow-[0_0_50px_rgba(0,0,0,0.8),0_0_20px_rgba(0,207,255,0.15)] overflow-hidden my-4 bg-[#07102a]'
            : 'max-w-2xl min-h-screen sm:border-x border-[#2c345e]/40 shadow-2xl bg-[#07102a]'
        }`}
        style={{
          backgroundImage: `linear-gradient(rgba(7, 16, 42, 0.95), rgba(7, 16, 42, 0.98)), url(${bgImg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        {/* Device Status Bar in Frame Mode */}
        {isDeviceFrame && (
          <div className="h-[28px] bg-[#07102a] px-6 flex items-center justify-between text-[11px] font-mono-code text-[#a8b0c8] select-none border-b border-[#2c345e]/30 shrink-0">
            <span className="font-bold text-white">09:03</span>
            <div className="w-16 h-3.5 bg-black/60 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5">
              <Signal className="w-3 h-3 text-white" />
              <Wifi className="w-3 h-3 text-white" />
              <BatteryMedium className="w-3.5 h-3.5 text-white" />
            </div>
          </div>
        )}

        {/* Application Header */}
        {showHeader && (
          <Header
            title={getPageTitle(currentPage)}
            onOpenDrawer={() => setIsDrawerOpen(true)}
            onOpenProfile={() => setCurrentPage('profile')}
            isDeviceFrame={isDeviceFrame}
            onToggleDeviceFrame={() => setIsDeviceFrame(!isDeviceFrame)}
          />
        )}

        {/* Dynamic Content Body */}
        <main className="flex-1 flex flex-col overflow-y-auto">
          {renderCurrentView()}
        </main>

        {/* Bottom Navigation */}
        {showBottomNav && (
          <footer className="shrink-0">
            <BottomNav
              currentPage={currentPage}
              onNavigate={(page) => setCurrentPage(page)}
            />
          </footer>
        )}

        {/* Home gesture pill indicator for frame mode */}
        {isDeviceFrame && (
          <div className="h-4 flex items-center justify-center pb-1 shrink-0">
            <div className="w-28 h-1 rounded-full bg-white/20" />
          </div>
        )}
      </div>
    </div>
  );
}
