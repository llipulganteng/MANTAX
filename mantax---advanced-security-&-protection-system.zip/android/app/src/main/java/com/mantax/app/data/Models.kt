package com.mantax.app.data

enum class Role {
    MEMBER,
    ADMIN,
    OWNER,
    DEV
}

enum class Expiry(val label: String) {
    ONE_DAY("1 HARI"),
    ONE_MONTH("1 BULAN"),
    ONE_YEAR("1 TAHUN"),
    PERMANENT("PERMANEN")
}

data class UserAccount(
    val id: String,
    val name: String,
    val username: String,
    val password: String,
    val role: Role,
    val expiry: Expiry,
    val photoUrl: String = "",
    val createdAt: String
)

object AccountRepository {
    // Owner name is ANSEN ANTONIO, credentials 09 / 03
    val defaultAccounts = mutableListOf(
        UserAccount(
            id = "acc-01",
            name = "ANSEN ANTONIO",
            username = "09",
            password = "03",
            role = Role.OWNER,
            expiry = Expiry.PERMANENT,
            photoUrl = "",
            createdAt = "2026-01-01 00:00:00"
        ),
        UserAccount(
            id = "acc-02",
            name = "Admin Mantax Core",
            username = "admin01",
            password = "777",
            role = Role.ADMIN,
            expiry = Expiry.ONE_YEAR,
            photoUrl = "",
            createdAt = "2026-02-15 12:30:00"
        ),
        UserAccount(
            id = "acc-03",
            name = "Dev Mantax Engine",
            username = "dev_ops",
            password = "dev",
            role = Role.DEV,
            expiry = Expiry.PERMANENT,
            photoUrl = "",
            createdAt = "2026-02-20 10:15:00"
        ),
        UserAccount(
            id = "acc-04",
            name = "User Client Member",
            username = "member01",
            password = "123",
            role = Role.MEMBER,
            expiry = Expiry.ONE_MONTH,
            photoUrl = "",
            createdAt = "2026-03-01 16:40:00"
        )
    )

    // Role-based access control for account creation
    fun getAllowedRoles(currentRole: Role): List<Role> {
        return when (currentRole) {
            Role.DEV -> listOf(Role.MEMBER, Role.ADMIN, Role.OWNER, Role.DEV)
            Role.OWNER -> listOf(Role.MEMBER, Role.ADMIN, Role.OWNER)
            Role.ADMIN -> listOf(Role.MEMBER)
            Role.MEMBER -> emptyList() // MEMBER cannot create accounts
        }
    }
}
