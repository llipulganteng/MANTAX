package com.mantax.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.data.AccountRepository
import com.mantax.app.data.UserAccount
import com.mantax.app.ui.navigation.Screen
import com.mantax.app.ui.screens.*
import com.mantax.app.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MantaxTheme {
                MantaxApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MantaxApp() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Splash) }
    var currentUser by remember { mutableStateOf(AccountRepository.defaultAccounts[0]) } // ANSEN ANTONIO, OWNER
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MantaxDrawerBg,
                modifier = Modifier.width(300.dp)
            ) {
                Spacer(Modifier.height(24.dp))
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                    Text(
                        text = "MANTAX",
                        fontSize = 26.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold,
                        color = MantaxCyan
                    )
                    Text(
                        text = currentUser.name, // ANSEN ANTONIO
                        fontSize = 14.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                        color = MantaxWhite
                    )
                    Text(
                        text = "${currentUser.role} • @${currentUser.username}",
                        fontSize = 11.sp,
                        color = MantaxMuted
                    )
                }

                HorizontalDivider(color = MantaxBorder, modifier = Modifier.padding(vertical = 12.dp))

                NavigationDrawerItem(
                    label = { Text("⌂  Home", color = MantaxWhite) },
                    selected = currentScreen == Screen.Home,
                    onClick = {
                        currentScreen = Screen.Home
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                NavigationDrawerItem(
                    label = { Text("♟  Owner Page", color = MantaxWhite) },
                    selected = currentScreen == Screen.Accounts,
                    onClick = {
                        currentScreen = Screen.Accounts
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                NavigationDrawerItem(
                    label = { Text("☷  Rules & Info", color = MantaxWhite) },
                    selected = currentScreen == Screen.Rules,
                    onClick = {
                        currentScreen = Screen.Rules
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                NavigationDrawerItem(
                    label = { Text("📦  APK Manager", color = MantaxWhite) },
                    selected = currentScreen == Screen.ApkManager,
                    onClick = {
                        currentScreen = Screen.ApkManager
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                NavigationDrawerItem(
                    label = { Text("⌖  Location", color = MantaxWhite) },
                    selected = currentScreen == Screen.Location,
                    onClick = {
                        currentScreen = Screen.Location
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                Spacer(modifier = Modifier.weight(1f))

                NavigationDrawerItem(
                    label = { Text("↪  Log Out", color = MaterialTheme.colorScheme.error) },
                    selected = false,
                    onClick = {
                        currentScreen = Screen.Login
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(12.dp)
                )
            }
        }
    ) {
        val showBar = currentScreen != Screen.Splash && currentScreen != Screen.Login

        Scaffold(
            topBar = {
                if (showBar) {
                    TopAppBar(
                        title = {
                            Text(
                                text = currentScreen.title,
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                                color = MantaxWhite,
                                fontSize = 18.sp
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = MantaxCyan)
                            }
                        },
                        actions = {
                            IconButton(onClick = { currentScreen = Screen.Profile }) {
                                Icon(Icons.Default.AccountCircle, contentDescription = "Profile", tint = MantaxCyan)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MantaxBg)
                    )
                }
            },
            bottomBar = {
                if (showBar) {
                    NavigationBar(
                        containerColor = MantaxNavBg,
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .clip(RoundedCornerShape(30.dp))
                    ) {
                        NavigationBarItem(
                            selected = currentScreen == Screen.Home,
                            onClick = { currentScreen = Screen.Home },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                            label = { Text("Home", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MantaxCyan,
                                selectedTextColor = MantaxCyan,
                                indicatorColor = MantaxPanel
                            )
                        )

                        NavigationBarItem(
                            selected = currentScreen == Screen.BugNomor || currentScreen == Screen.BugGroup,
                            onClick = { currentScreen = Screen.BugNomor },
                            icon = { Icon(Icons.Default.Security, contentDescription = "Bug") },
                            label = { Text("Bug", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MantaxCyan,
                                selectedTextColor = MantaxCyan,
                                indicatorColor = MantaxPanel
                            )
                        )

                        NavigationBarItem(
                            selected = currentScreen == Screen.Accounts,
                            onClick = { currentScreen = Screen.Accounts },
                            icon = { Icon(Icons.Default.Group, contentDescription = "Accounts") },
                            label = { Text("Account", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MantaxCyan,
                                selectedTextColor = MantaxCyan,
                                indicatorColor = MantaxPanel
                            )
                        )

                        NavigationBarItem(
                            selected = currentScreen == Screen.Tools || currentScreen == Screen.ApkManager || currentScreen == Screen.Location,
                            onClick = { currentScreen = Screen.Tools },
                            icon = { Icon(Icons.Default.Build, contentDescription = "Tools") },
                            label = { Text("Tools", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MantaxCyan,
                                selectedTextColor = MantaxCyan,
                                indicatorColor = MantaxPanel
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MantaxBg)
            ) {
                when (currentScreen) {
                    Screen.Splash -> SplashScreen(onTimeout = { currentScreen = Screen.Home })
                    Screen.Login -> LoginScreen(onLoginSuccess = { user ->
                        currentUser = user
                        currentScreen = Screen.Home
                    })
                    Screen.Home -> HomeScreen(
                        currentUser = currentUser,
                        onNavigateBug = { type ->
                            currentScreen = if (type == "nomor") Screen.BugNomor else Screen.BugGroup
                        },
                        onNavigateRules = { currentScreen = Screen.Rules },
                        onNavigateProfile = { currentScreen = Screen.Profile }
                    )
                    Screen.BugNomor -> BugScreen("nomor", onBack = { currentScreen = Screen.Home })
                    Screen.BugGroup -> BugScreen("group", onBack = { currentScreen = Screen.Home })
                    Screen.Accounts -> AccountScreen(currentUser = currentUser)
                    Screen.Tools -> ToolsScreen(
                        onNavigateApkManager = { currentScreen = Screen.ApkManager },
                        onNavigateLocation = { currentScreen = Screen.Location },
                        onNavigateRules = { currentScreen = Screen.Rules }
                    )
                    Screen.ApkManager -> ApkManagerScreen(onBack = { currentScreen = Screen.Tools })
                    Screen.Location -> LocationScreen(onBack = { currentScreen = Screen.Tools })
                    Screen.Rules -> RulesScreen(onBack = { currentScreen = Screen.Home })
                    Screen.Profile -> ProfileScreen(
                        currentUser = currentUser,
                        onBack = { currentScreen = Screen.Home },
                        onLogout = { currentScreen = Screen.Login }
                    )
                }
            }
        }
    }
}
