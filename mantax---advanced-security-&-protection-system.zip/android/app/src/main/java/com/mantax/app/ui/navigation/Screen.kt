package com.mantax.app.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Splash : Screen("splash", "MANTAX")
    object Login : Screen("login", "MANTAX LOGIN")
    object Home : Screen("home", "MANTAX")
    object BugNomor : Screen("bug_nomor", "BUG NOMOR")
    object BugGroup : Screen("bug_group", "BUG GROUP")
    object Accounts : Screen("accounts", "ACCOUNTS")
    object Tools : Screen("tools", "TOOLS")
    object ApkManager : Screen("apk_manager", "APK MANAGER")
    object Location : Screen("location", "LOCATION")
    object Rules : Screen("rules", "RULES & INFO")
    object Profile : Screen("profile", "PROFILE")
}
