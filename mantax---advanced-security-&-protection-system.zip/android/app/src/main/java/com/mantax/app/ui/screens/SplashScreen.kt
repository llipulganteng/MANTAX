package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onTimeout: () -> Unit
) {
    LaunchedEffect(Unit) {
        delay(1400)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Cyber Emblem Placeholder Box
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MantaxPanel),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "MTX",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MantaxCyan
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "MANTAX",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MantaxCyan,
                letterSpacing = 2.sp
            )

            Text(
                text = "Advanced Security & Protection System",
                fontSize = 12.sp,
                color = MantaxMuted,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(36.dp))

            CircularProgressIndicator(
                color = MantaxCyan,
                strokeWidth = 3.dp,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "LOADING...",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MantaxWhite,
                letterSpacing = 1.5.sp
            )
        }
    }
}
