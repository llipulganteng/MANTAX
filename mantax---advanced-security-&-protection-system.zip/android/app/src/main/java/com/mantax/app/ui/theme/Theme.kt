package com.mantax.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = MantaxCyan,
    secondary = MantaxBlue,
    tertiary = MantaxCyan,
    background = MantaxBg,
    surface = MantaxPanel,
    onPrimary = MantaxBg,
    onSecondary = MantaxWhite,
    onBackground = MantaxWhite,
    onSurface = MantaxWhite
)

@Composable
fun MantaxTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
