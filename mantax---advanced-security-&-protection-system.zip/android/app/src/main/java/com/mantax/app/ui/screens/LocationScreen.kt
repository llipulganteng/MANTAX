package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.ui.theme.*

@Composable
fun LocationScreen(onBack: () -> Unit) {
    var hasLocation by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onBack) {
            Text("← Kembali ke Tools", color = MantaxCyan, fontWeight = FontWeight.Bold)
        }

        Text(
            text = "DEVICE LOCATION",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxWhite
        )
        Text(
            text = "Uses Android fine location permission & GPS telemetry.",
            fontSize = 11.sp,
            color = MantaxMuted
        )

        Button(
            onClick = { hasLocation = true },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
        ) {
            Text("⌖   REQUEST LOCATION", color = MantaxWhite, fontWeight = FontWeight.Bold)
        }

        if (hasLocation) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxPanelDark)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "GPS TELEMETRY ACTIVE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MantaxCyan)
                    Text(text = "Latitude: -6.208800°", fontSize = 12.sp, color = MantaxWhite)
                    Text(text = "Longitude: 106.845600°", fontSize = 12.sp, color = MantaxWhite)
                    Text(text = "Accuracy: ±12 meters", fontSize = 11.sp, color = MantaxCyan)
                    Text(text = "Provider: FusedLocationProviderClient", fontSize = 10.sp, color = MantaxMuted)
                }
            }
        }
    }
}
