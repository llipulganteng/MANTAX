package com.mantax.app.ui.theme

import androidx.compose.ui.graphics.Color

val MantaxBg = Color(0xFF07102A)
val MantaxPanel = Color(0xFF151A3D)
val MantaxPanelDark = Color(0xFF0C122D)
val MantaxCyan = Color(0xFF00CFFF)
val MantaxBlue = Color(0xFF246BFF)
val MantaxWhite = Color(0xFFF4F7FF)
val MantaxMuted = Color(0xFFA8B0C8)
val MantaxBorder = Color(0xFF2C345E)
val MantaxNavBg = Color(0xFF131B37)
val MantaxDrawerBg = Color(0xFF070E27)
val MantaxCardRule = Color(0xFF1E233B)
