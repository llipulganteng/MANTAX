package com.mantax.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.data.UserAccount
import com.mantax.app.ui.theme.*

@Composable
fun HomeScreen(
    currentUser: UserAccount,
    onNavigateBug: (String) -> Unit,
    onNavigateRules: () -> Unit,
    onNavigateProfile: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // PROFILE CARD: PP & Nama terpisah
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(MantaxPanel)
                .border(1.dp, MantaxBorder, RoundedCornerShape(22.dp))
                .clickable { onNavigateProfile() }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Foto Profil (PP)
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxPanelDark)
                    .border(1.dp, MantaxCyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "MTX",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MantaxCyan
                )
            }

            // Nama & Role terpisah
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = currentUser.name, // Must be ANSEN ANTONIO
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MantaxWhite
                )
                Text(
                    text = "@${currentUser.username}",
                    fontSize = 11.sp,
                    color = MantaxCyan
                )
                Text(
                    text = "${currentUser.role}   •   Exp: ${currentUser.expiry.label}",
                    fontSize = 11.sp,
                    color = MantaxMuted
                )
            }
        }

        // STATISTICS (Gacor, 3, Fast Send)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(98.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxPanelDark)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🔥", fontSize = 20.sp)
                    Text(text = "Gacor", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                    Text(text = "99.9% Uptime", fontSize = 9.sp, color = MantaxCyan)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(98.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxPanelDark)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "☘", fontSize = 20.sp)
                    Text(text = "3", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                    Text(text = "Shield Nodes", fontSize = 9.sp, color = MantaxMuted)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(98.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxPanelDark)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "⚡", fontSize = 20.sp)
                    Text(text = "Fast Send", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                    Text(text = "<15ms Latency", fontSize = 9.sp, color = MantaxCyan)
                }
            }
        }

        // BUG TABS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onNavigateBug("nomor") },
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
            ) {
                Text(text = "▣  BUG NOMOR", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
            }

            Button(
                onClick = { onNavigateBug("group") },
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
            ) {
                Text(text = "♟  BUG GROUP", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
            }
        }

        // Target Preview
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MantaxPanel)
                .border(1.dp, MantaxBorder, RoundedCornerShape(16.dp))
                .clickable { onNavigateBug("nomor") }
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "TARGET:  +62XXXXXXXXXX", fontSize = 13.sp, color = MantaxWhite)
                Text(text = "Select →", fontSize = 11.sp, color = MantaxCyan)
            }
        }

        // Section header
        Text(
            text = "▌ PILIH BUG",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxCyan
        )

        // QUICK ACTIONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onNavigateBug("nomor") },
                modifier = Modifier
                    .weight(1f)
                    .height(96.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "⚙", fontSize = 20.sp)
                    Text(text = "Manage Bug", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                }
            }

            Button(
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/AZXV71"))
                    context.startActivity(intent)
                },
                modifier = Modifier
                    .weight(1f)
                    .height(96.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "➤", fontSize = 20.sp)
                    Text(text = "Join Channel", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                }
            }

            Button(
                onClick = { onNavigateRules() },
                modifier = Modifier
                    .weight(1f)
                    .height(96.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "☷", fontSize = 20.sp)
                    Text(text = "Rules & Info", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                }
            }
        }
    }
}
