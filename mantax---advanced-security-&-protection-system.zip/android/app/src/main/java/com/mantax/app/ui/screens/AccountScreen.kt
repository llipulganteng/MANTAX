package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.data.*
import com.mantax.app.ui.theme.*

@Composable
fun AccountScreen(
    currentUser: UserAccount
) {
    var accountsList by remember { mutableStateOf(AccountRepository.defaultAccounts.toList()) }
    var showCreateDialog by remember { mutableStateOf(false) }

    // Form states
    var nameInput by remember { mutableStateOf("") }
    var usernameInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var roleInput by remember { mutableStateOf(Role.MEMBER) }
    var expiryInput by remember { mutableStateOf(Expiry.PERMANENT) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val allowedRoles = AccountRepository.getAllowedRoles(currentUser.role)
    val isMember = currentUser.role == Role.MEMBER

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ACCOUNT MANAGEMENT",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MantaxWhite
                )
                Text(
                    text = "Kelola akun pengguna berjenjang",
                    fontSize = 11.sp,
                    color = MantaxMuted
                )
            }

            if (!isMember) {
                Button(
                    onClick = {
                        nameInput = ""
                        usernameInput = ""
                        passwordInput = ""
                        roleInput = allowedRoles.firstOrNull() ?: Role.MEMBER
                        expiryInput = Expiry.PERMANENT
                        errorMessage = null
                        showCreateDialog = true
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MantaxCyan)
                ) {
                    Text("+ BUAT AKUN", color = MantaxBg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        // Access Notice if Member
        if (isMember) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MantaxPanel)
                    .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "Akses Dibatasi: Role Anda adalah MEMBER. Role MEMBER tidak diizinkan untuk membuat akun baru.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }

        Text(
            text = "DAFTAR AKUN & MEMBER (${accountsList.size})",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxCyan
        )

        // List of Accounts
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(accountsList) { acc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(MantaxPanel)
                        .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Foto profil (PP) terpisah
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MantaxPanelDark)
                            .border(1.dp, MantaxCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = acc.name.take(2).uppercase(),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MantaxCyan
                        )
                    }

                    // Nama, Username, Role & Expired terpisah
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = acc.name, // e.g. ANSEN ANTONIO
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MantaxWhite
                            )
                            Text(
                                text = acc.role.name,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (acc.role) {
                                    Role.DEV -> MantaxCyan
                                    Role.OWNER -> MantaxCyan
                                    Role.ADMIN -> MantaxBlue
                                    Role.MEMBER -> MantaxWhite
                                }
                            )
                        }

                        Text(
                            text = "@${acc.username}   •   Exp: ${acc.expiry.label}",
                            fontSize = 11.sp,
                            color = MantaxMuted
                        )
                    }
                }
            }
        }

        // Form Pembuatan Akun Modal
        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                containerColor = MantaxPanel,
                title = {
                    Text(
                        text = "FORM PEMBUATAN AKUN",
                        fontWeight = FontWeight.Bold,
                        color = MantaxWhite
                    )
                },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            placeholder = { Text("Nama Lengkap", color = MantaxMuted) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = usernameInput,
                            onValueChange = { usernameInput = it },
                            placeholder = { Text("Username", color = MantaxMuted) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            placeholder = { Text("Password", color = MantaxMuted) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Text("Pilih Role:", fontSize = 11.sp, color = MantaxCyan)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            allowedRoles.forEach { r ->
                                FilterChip(
                                    selected = roleInput == r,
                                    onClick = { roleInput = r },
                                    label = { Text(r.name, fontSize = 10.sp) }
                                )
                            }
                        }

                        Text("Pilih Expired:", fontSize = 11.sp, color = MantaxCyan)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Expiry.values().forEach { exp ->
                                FilterChip(
                                    selected = expiryInput == exp,
                                    onClick = { expiryInput = exp },
                                    label = { Text(exp.label, fontSize = 9.sp) }
                                )
                            }
                        }

                        errorMessage?.let {
                            Text(text = it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val cleanName = nameInput.trim()
                            val cleanUser = usernameInput.trim()
                            val cleanPass = passwordInput.trim()

                            if (cleanName.isBlank() || cleanUser.isBlank() || cleanPass.isBlank()) {
                                errorMessage = "Semua field harus diisi"
                                return@Button
                            }

                            val newAcc = UserAccount(
                                id = "acc-${System.currentTimeMillis()}",
                                name = cleanName,
                                username = cleanUser,
                                password = cleanPass,
                                role = roleInput,
                                expiry = expiryInput,
                                photoUrl = "",
                                createdAt = "2026-03-31 00:00:00"
                            )

                            AccountRepository.defaultAccounts.add(0, newAcc)
                            accountsList = AccountRepository.defaultAccounts.toList()
                            showCreateDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MantaxCyan)
                    ) {
                        Text("SIMPAN AKUN", color = MantaxBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("BATAL", color = MantaxMuted)
                    }
                }
            )
        }
    }
}
