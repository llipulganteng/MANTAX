package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.data.UserAccount
import com.mantax.app.ui.theme.*

@Composable
fun ProfileScreen(
    currentUser: UserAccount,
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            TextButton(onClick = onBack) {
                Text("← Kembali", color = MantaxCyan, fontWeight = FontWeight.Bold)
            }
        }

        // PP terpisah
        Box(
            modifier = Modifier
                .size(130.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(MantaxPanel)
                .border(2.dp, MantaxCyan, RoundedCornerShape(26.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "MTX",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MantaxCyan
            )
        }

        // Nama & Role terpisah
        Text(
            text = currentUser.name, // ANSEN ANTONIO
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxWhite
        )

        Text(
            text = "@${currentUser.username}   •   ${currentUser.role}   •   Exp: ${currentUser.expiry.label}",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxCyan
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onLogout,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.2f))
        ) {
            Text(text = "↪   LOG OUT", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
    }
}
