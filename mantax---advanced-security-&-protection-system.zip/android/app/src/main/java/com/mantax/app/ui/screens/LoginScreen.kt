package com.mantax.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.data.AccountRepository
import com.mantax.app.data.UserAccount
import com.mantax.app.ui.theme.*

@Composable
fun LoginScreen(
    onLoginSuccess: (UserAccount) -> Unit
) {
    val context = LocalContext.current
    var showDialog by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 40.dp)
            ) {
                // Emblem
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(MantaxPanel)
                        .border(1.dp, MantaxCyan.copy(alpha = 0.4f), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "MANTAX",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MantaxCyan
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "MANTAX",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MantaxCyan,
                    letterSpacing = 2.sp
                )

                Text(
                    text = "Advanced Security & Protection System",
                    fontSize = 12.sp,
                    color = MantaxMuted,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(36.dp))

                // Sign in action button
                Button(
                    onClick = { showDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
                ) {
                    Text(
                        text = "↪   SIGN IN",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MantaxWhite
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "CONNECT WITH US",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MantaxCyan
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/AZXV71"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
                    ) {
                        Text("◉  Telegram", fontSize = 12.sp, color = MantaxWhite)
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/053897312223"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
                    ) {
                        Text("◉  WhatsApp", fontSize = 12.sp, color = MantaxWhite)
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Text(
                    text = "© 2026 MANTAX",
                    fontSize = 11.sp,
                    color = MantaxMuted
                )
                Text(
                    text = "● Secure     ● Reliable     ● Professional",
                    fontSize = 10.sp,
                    color = MantaxMuted.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Login Dialog (AlertDialog)
        if (showDialog) {
            AlertDialog(
                onDismissRequest = { showDialog = false },
                containerColor = MantaxPanel,
                title = {
                    Text(
                        text = "MANTAX LOGIN",
                        fontWeight = FontWeight.Bold,
                        color = MantaxWhite
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Owner PIN: User 09 | Pass 03",
                            fontSize = 11.sp,
                            color = MantaxCyan
                        )

                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            placeholder = { Text("Username", color = MantaxMuted) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            placeholder = { Text("Password", color = MantaxMuted) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )

                        errorMessage?.let {
                            Text(text = it, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val userClean = username.trim()
                            val passClean = password.trim()
                            val matched = AccountRepository.defaultAccounts.find {
                                it.username == userClean && it.password == passClean
                            }
                            if (userClean == "09" && passClean == "03") {
                                showDialog = false
                                onLoginSuccess(AccountRepository.defaultAccounts[0])
                            } else if (matched != null) {
                                showDialog = false
                                onLoginSuccess(matched)
                            } else {
                                errorMessage = "Username atau password salah"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MantaxCyan)
                    ) {
                        Text("SIGN IN", color = MantaxBg, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDialog = false }) {
                        Text("BATAL", color = MantaxMuted)
                    }
                }
            )
        }
    }
}
