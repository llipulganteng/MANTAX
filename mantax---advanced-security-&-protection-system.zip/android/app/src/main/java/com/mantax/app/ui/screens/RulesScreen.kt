package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.ui.theme.*

@Composable
fun RulesScreen(onBack: () -> Unit) {
    val rules = listOf(
        "1. Larangan Barter Akun" to "Akun tidak boleh ditukar dengan barang, jasa, atau akun lain.",
        "2. Larangan Membagikan Akun" to "Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik.",
        "3. Larangan Menjual Akun" to "Penjualan akun hanya boleh dilakukan oleh role yang diizinkan (OWNER / DEV).",
        "4. Larangan Jual Durasi Ilegal" to "Dilarang menjual akses di luar ketentuan resmi.",
        "5. Larangan Banting Harga" to "Dilarang merusak atau menurunkan harga yang telah ditentukan."
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack) {
            Text("← Kembali", color = MantaxCyan, fontWeight = FontWeight.Bold)
        }

        Text(
            text = "RULES & INFO",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxWhite
        )
        Text(
            text = "Tata tertib resmi keanggotaan dan protokol keamanan ekosistem MANTAX.",
            fontSize = 11.sp,
            color = MantaxMuted
        )

        rules.forEach { (title, desc) ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxCardRule)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                    Text(text = desc, fontSize = 11.sp, color = MantaxMuted, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}
