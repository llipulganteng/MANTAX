package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.ui.theme.*

@Composable
fun BugScreen(
    type: String, // "nomor" or "group"
    onBack: () -> Unit
) {
    val isNomor = type == "nomor"
    var targetInput by remember { mutableStateOf(if (isNomor) "+6281234567890" else "MANTAX-CYBER-OPS") }
    var isRunning by remember { mutableStateOf(false) }
    var auditDone by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("← Kembali", color = MantaxCyan, fontWeight = FontWeight.Bold)
            }
            Text(
                text = if (isNomor) "BUG NOMOR" else "BUG GROUP",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MantaxWhite
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MantaxPanelDark)
                .border(1.dp, MantaxBorder, RoundedCornerShape(14.dp))
                .padding(12.dp)
        ) {
            Text(
                text = "Security analysis only — no spam, flooding, OTP abuse, or crash actions.",
                fontSize = 11.sp,
                color = MantaxMuted
            )
        }

        Text(
            text = if (isNomor) "Target Number" else "Target Group",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxCyan
        )

        OutlinedTextField(
            value = targetInput,
            onValueChange = { targetInput = it },
            placeholder = { Text(if (isNomor) "+62xxxxxxxxxx" else "Group ID / Name", color = MantaxMuted) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            text = "AVAILABLE CHECKS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxCyan
        )

        val checks = listOf(
            "Format validation" to "Verify E.164 standard & carrier syntax.",
            "Reachability status" to "Ping network route & carrier latency.",
            "Input normalization" to "Sanitize hidden unicode & payload sequences.",
            "Local safety checks" to "Compliance verified: Zero spam/flood abuse signatures."
        )

        checks.forEach { (title, desc) ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MantaxPanel)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "✓ $title", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                        Text(text = desc, fontSize = 10.sp, color = MantaxMuted)
                    }
                    Text(text = "READY", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MantaxCyan)
                }
            }
        }

        Button(
            onClick = {
                isRunning = true
                auditDone = true
                isRunning = false
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MantaxCyan)
        ) {
            Text(
                text = if (isRunning) "ANALYZING..." else "EXECUTE SECURITY AUDIT",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MantaxBg
            )
        }

        if (auditDone) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MantaxDrawerBg)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = "DIAGNOSTIC CONSOLE:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MantaxCyan)
                    Text(text = "Target: $targetInput", fontSize = 11.sp, color = MantaxWhite)
                    Text(text = "Format: PASSED (E.164 Valid)", fontSize = 10.sp, color = MantaxWhite)
                    Text(text = "Gateway Ack: 14ms latency", fontSize = 10.sp, color = MantaxWhite)
                    Text(text = "Status: 100% SECURE & VERIFIED", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MantaxCyan)
                }
            }
        }
    }
}
