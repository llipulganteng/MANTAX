package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.ui.theme.*

@Composable
fun ApkManagerScreen(onBack: () -> Unit) {
    var apkList by remember { mutableStateOf(listOf("Mantax-Security-v2.8.apk (18.4 MB)")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack) {
            Text("← Kembali ke Tools", color = MantaxCyan, fontWeight = FontWeight.Bold)
        }

        Text(
            text = "APK MANAGER",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxWhite
        )
        Text(
            text = "Manage and install APK files on this Android device.",
            fontSize = 11.sp,
            color = MantaxMuted
        )

        Button(
            onClick = {
                apkList = apkList + "Mantax-Core-v2.8.apk (12.2 MB)"
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
        ) {
            Text("＋   ADD APK", color = MantaxWhite, fontWeight = FontWeight.Bold)
        }

        Button(
            onClick = { apkList = emptyList() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MantaxPanel)
        ) {
            Text("🗑   CLEAR LIST", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }

        Text(
            text = "INSTALLED / STORED PACKAGES",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxCyan,
            modifier = Modifier.padding(top = 8.dp)
        )

        apkList.forEach { apk ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MantaxPanel)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Text(text = "▣   $apk", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
            }
        }
    }
}
