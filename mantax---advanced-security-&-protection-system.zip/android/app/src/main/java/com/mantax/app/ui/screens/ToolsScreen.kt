package com.mantax.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mantax.app.ui.theme.*

@Composable
fun ToolsScreen(
    onNavigateApkManager: () -> Unit,
    onNavigateLocation: () -> Unit,
    onNavigateRules: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MantaxBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "TOOLS",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MantaxWhite
        )
        Text(
            text = "Utilitas diagnostik, pengelola paket, dan telemetri lokasi.",
            fontSize = 11.sp,
            color = MantaxMuted
        )

        val items = listOf(
            Triple("📦   APK MANAGER", "Kelola dan pasang paket APK Android di perangkat ini.", onNavigateApkManager),
            Triple("⌖   LOCATION", "Telemetri satelit GPS dan koordinat perangkat fisik.", onNavigateLocation),
            Triple("☷   RULES & INFO", "Tata tertib, pedoman harga, dan kebijakan akun.", onNavigateRules)
        )

        items.forEach { (title, subtitle, onClick) ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(MantaxPanel)
                    .border(1.dp, MantaxBorder, RoundedCornerShape(18.dp))
                    .clickable { onClick() }
                    .padding(16.dp)
            ) {
                Column {
                    Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MantaxWhite)
                    Text(text = subtitle, fontSize = 11.sp, color = MantaxMuted, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}
